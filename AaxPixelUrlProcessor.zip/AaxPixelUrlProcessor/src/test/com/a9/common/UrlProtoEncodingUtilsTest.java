package com.a9.common;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.google.common.collect.ImmutableSet;

public class UrlProtoEncodingUtilsTest {

    private static final String V0_PREFIX = "v0_";
    private static final String V1_PREFIX = "v1_";
    private static final String V0_NII_PREFIX = "v0-nii_";
    private static final String CLV0_PREFIX = "clv0_";

    private static final String PAYLOAD = "anGhX1laZlozXqC3CaFSgo1B9cC6q6DgTYpKT9fhu3n9pYgYSBdiW8eX41acJeup5is-K1GSYhMv-L3bEXALQsk8pQC-j8VqLAU8QuT62Eq-7hggqoNxZY5dkAYCdjJkKvfF32KmjlhBsobMyBJLbTw409DZAdzD4B1AQarcDZI6OV1TFQ7qMmSC_j3sRaRGfOcrESIUrNJBmi-lmj42lgPWszcSiZ2wNG9O0ejEwjS9nisbxTRVEKryX8O7nHokogILAjJv5JyXj1MCGlDYAyQWmv3knE3MQMFZHav5C-imph2j0B34KNS4bU0NfNXd9G_BbpXk-6LH-20Ir1UzseOSZFqJbAYcJRWXijXj_PbbwRVqdwspzRedwvOt8gBzHs8A9A4u2x8Tvuq6kPue9eubk5N8Y6BL23VTK3MYEiZxSx_j";
    private static final String V0_PAYLOAD = V0_PREFIX + PAYLOAD;
    private static final String V1_PAYLOAD = V1_PREFIX + PAYLOAD;
    private static final String V0_NII_PAYLOAD = V0_NII_PREFIX + PAYLOAD;
    private static final String CLV0_PAYLOAD = CLV0_PREFIX + PAYLOAD;
    
    private static final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(V0_PREFIX, V1_PREFIX);

    @Test
    public void isCompatiblePayload() {
        assertTrue(UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, V0_PREFIX));
        assertFalse(UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, V0_NII_PREFIX));
    }

    @Test
    public void extractSupportedVersionPrefix() {
        assertEquals(V0_PREFIX, UrlProtoEncodingUtils.extractVersionPrefix(V0_PAYLOAD));
        assertEquals(V0_NII_PREFIX, UrlProtoEncodingUtils.extractVersionPrefix(V0_NII_PAYLOAD));
        assertEquals(CLV0_PREFIX, UrlProtoEncodingUtils.extractVersionPrefix(CLV0_PAYLOAD));
    }
}
