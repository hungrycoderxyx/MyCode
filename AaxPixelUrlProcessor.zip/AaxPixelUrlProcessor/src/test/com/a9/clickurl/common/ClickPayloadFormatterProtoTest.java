package com.a9.clickurl.common;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.a9.clickurl.proto.AdspClickPayload;
import com.a9.clickurl.proto.AdspClickPayload.SlotBid;
import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.NoOpEncryptor;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.common.compression.PayloadCompressor;
import com.a9.cpx.common.util.StringUtil;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Base64;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class ClickPayloadFormatterProtoTest {

    private ClickPayloadFormatterProto testFormatter;

    @Before
    public void setUp() throws Exception {
        testFormatter = new ClickPayloadFormatterProto();
        testFormatter.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void testFormatter_full_data() {
        AdspClickPayload testProto = prepareTestProto();
        String encoded = testFormatter.formatToString(testProto);
        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        String encodedFromDecoded = testFormatter.formatToString(decoded);

        Assert.assertTrue(encoded.startsWith(testFormatter.getCurrentVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        Assert.assertEquals(encoded, encodedFromDecoded);

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    @Test
    public void testFormatter_compressed() {
        AdspClickPayload testProto = prepareTestProto();

        PayloadCompressor compressorMock = Mockito.mock(PayloadCompressor.class);
        when(compressorMock.compress(any(byte[].class))).thenReturn(testProto.toByteArray());
        when(compressorMock.decompress(any(byte[].class))).thenReturn(testProto.toByteArray());
        testFormatter.setCompressor(compressorMock);

        String encoded = testFormatter.formatToString(testProto, true);
        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        String encodedFromDecoded = testFormatter.formatToString(decoded, true);

        Assert.assertTrue(encoded.startsWith(testFormatter.getCurrentCompressedVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        Assert.assertEquals(encoded, encodedFromDecoded);

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    @Test
    public void testFormatter_partial_data() {
        AdspClickPayload testProto = prepareTestProto();
        String encoded = testFormatter.formatToString(testProto);
        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        String encodedFromDecoded = testFormatter.formatToString(decoded);

        Assert.assertTrue(encoded.startsWith(testFormatter.getCurrentVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        Assert.assertEquals(encoded, encodedFromDecoded);

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    @Test
    public void testFormatter_nopadding_encode_add_padding_decode() throws UnsupportedEncodingException {
        AdspClickPayload testProto = prepareTestProto_partial_data();
        String encoded = testFormatter.formatToString(testProto);
        Assert.assertFalse(encoded.contains("="));
        Assert.assertFalse(encoded.contains(URLEncoder.encode("=", "utf-8"))); 
        
        String paddedEncoded = padB64UrlProtoPayload(encoded);
        AdspClickPayload decoded = testFormatter.formatFromString(paddedEncoded);
        String encodedFromDecoded = testFormatter.formatToString(decoded);

        Assert.assertTrue(encoded.startsWith(testFormatter.getCurrentVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        Assert.assertEquals(encoded, encodedFromDecoded);

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    @Test
    public void testFormatter_nopadding_encode_but_supply_extra_urlencoding() throws UnsupportedEncodingException {
        AdspClickPayload testProto = prepareTestProto();
        String encoded = testFormatter.formatToString(testProto);
        Assert.assertFalse(encoded.contains("="));
        Assert.assertFalse(encoded.contains(URLEncoder.encode("=", "utf-8")));
        
        // Simulated that supply / publish is accidently adding one more time of URL encoding
        URLEncoder.encode(encoded, "utf-8");
        Assert.assertFalse(encoded.contains("="));
        Assert.assertFalse(encoded.contains(URLEncoder.encode("=", "utf-8")));

        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        String encodedFromDecoded = testFormatter.formatToString(decoded);

        Assert.assertTrue(encoded.startsWith(testFormatter.getCurrentVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        Assert.assertEquals(encoded, encodedFromDecoded);

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    @Test(expected = AaxUrlProtoParsingException.class)
    public void testFormatter_padded_encode_and_supply_extra_urlencoding_badcase() throws UnsupportedEncodingException {
        AdspClickPayload testProto = prepareTestProto();
        String encoded = testFormatter.formatToString(testProto);
       
        encoded = padB64UrlProtoPayload(encoded);
        Assert.assertTrue(encoded.contains(URLEncoder.encode("=", "utf-8")));
        
        // https://sim.amazon.com/issues/P145240168
        // Simulated that supply / publisher accidentally adds one more time of URL encoding (double url encoded)
        encoded = URLEncoder.encode(encoded, "utf-8");
        String DOUBLE_ENCODED_PERCENT_MARKER = URLEncoder.encode(URLEncoder.encode("=", "utf-8"), "utf-8");
        Assert.assertTrue(encoded.contains(DOUBLE_ENCODED_PERCENT_MARKER));

        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        Assert.assertNull(decoded);
    }

    @Test
    public void testFormatFromString_null() {
        AdspClickPayload decoded = testFormatter.formatFromString(null);
        Assert.assertNull(decoded);
    }

    @Test(expected = AaxUrlProtoParsingException.class)
    public void testFormatFromString_error_alteredPayload() {
        AdspClickPayload testProto = prepareTestProto_partial_data();
        String encoded = testFormatter.formatToString(testProto);
        encoded = encoded + "12345678_bad_suffix";
        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        Assert.assertNull(decoded);
    }
    
    @Test
    public void testFormatFromString_unsupportedVersion() {
        AdspClickPayload decoded = testFormatter.formatFromString("badversion_123456");
        Assert.assertNull(decoded);
    }
    
    @Test
    public void testFormatFromString_backwardCompatible_clv0() {
        String LEGACY_VERSION_PREFIX = "clv0_";
        AdspClickPayload testProto = prepareTestProto();
        String encoded = formatToStringLegacy(testProto, LEGACY_VERSION_PREFIX);

        AdspClickPayload decoded = testFormatter.formatFromString(encoded);
        String encodedFromDecoded = testFormatter.formatToString(testProto);

        Assert.assertNotNull(encoded);
        Assert.assertTrue(encoded.startsWith(LEGACY_VERSION_PREFIX));
        Assert.assertFalse(encoded.startsWith(testFormatter.getCurrentVersionPrefix()));
        Assert.assertTrue(StringUtil.isNullOrEmpty(decoded.getSlotBid().getSlotKey()));
        
        Assert.assertNotEquals(encoded, encodedFromDecoded);
        Assert.assertTrue(encodedFromDecoded.startsWith(testFormatter.getCurrentVersionPrefix()));

        Assert.assertEquals(decoded.getSlotBid().getBidderClickRequestUrl(), testProto.getSlotBid().getBidderClickRequestUrl());
        Assert.assertEquals(decoded.getRequestId(), testProto.getRequestId());
    }

    private AdspClickPayload prepareTestProto() {
        SlotBid clickSb = SlotBid.newBuilder().setBidId("test_bid_id")
                .setNetworkId(999)
                .setBidderClickRequestUrl("https://superlongbidderurl.com/bidder_payload_1KB")
                .build();

        return AdspClickPayload.newBuilder()
                .setBidTime(12345L)
                .setRequestId("test_req_id")
                .setSourceId(0)
                .setZone(1)
                .setSlotBid(clickSb)
                .build();
    }

    private AdspClickPayload prepareTestProto_partial_data() {
        SlotBid clickSb = SlotBid.newBuilder().setBidId("test_bid_id")
                .setNetworkId(999)
                .build();

        return AdspClickPayload.newBuilder()
                .setRequestId("test_req_id")
                .setSlotBid(clickSb)
                .build();
    }
    
    /*
    Open box logic for legacy version of payloads. No prod usage. 
     */
    private String formatToStringLegacy(AdspClickPayload payloadProto, String versionPrefix) {
        if (StringUtils.equals(versionPrefix,  testFormatter.getCurrentVersionPrefix())) {
            return testFormatter.formatToString(payloadProto);
        }

        if (StringUtils.equals(ClickPayloadFormatterProto.CLICK_PAYLOAD_V0, versionPrefix)) {
            byte[] encryptedBytes = testFormatter.getEncryptor().encrypt(payloadProto.toByteArray());
            encryptedBytes = Base64.getUrlEncoder().encode(encryptedBytes); // clv0_ used a encryptor with b64 bytes encoding embedded as part of encryption.
            return serializeForUrl(encryptedBytes, versionPrefix);
        }
        return null;
    }
    
    /*
    Manually Padding non-padded B64 URL string with "=" to test the decoding compatibility.
    Taking the AAX payload version prefix into consideration.
     */
    private String padB64UrlProtoPayload(String urlPayload) throws UnsupportedEncodingException{
        String prefix = UrlProtoEncodingUtils.extractVersionPrefix(urlPayload);
        String no_prefix_payload = urlPayload.substring(prefix.length());
        int numberOfPaddings = no_prefix_payload.length() % 4;
        // Manually add paddings to encoded B64 URL string
        for (int i=0; i < numberOfPaddings; i++) {
            no_prefix_payload = no_prefix_payload + URLEncoder.encode("=", "utf-8");
        }
        return prefix + no_prefix_payload;
    }
}
