package com.a9.impressionurl.common;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.NoOpEncryptor;
import com.a9.common.compression.PayloadCompressor;
import com.a9.impressionurl.proto.ImpressionPayload;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class ImpressionPayloadFormatterProtoTest {
    private ImpressionPayloadFormatterProto impressionPayloadFormatterProto;

    @Before
    public void setUp() throws Exception {
        impressionPayloadFormatterProto = new ImpressionPayloadFormatterProto();
        impressionPayloadFormatterProto.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void testFormatFromStringWithUnsupportedVersion() {
        Assert.assertNull(impressionPayloadFormatterProto.formatFromString("imv0_encodedString"));
    }

    @Test(expected = AaxUrlProtoParsingException.class)
    public void testFormatFromStringException() {
        impressionPayloadFormatterProto.formatFromString("imv1_encodedString");
    }

    @Test
    public void testFormatToStringAndFormatFromStringSuccess() {
        ImpressionPayload impressionPayload = prepareTestProto();

        PayloadCompressor compressorMock = Mockito.mock(PayloadCompressor.class);
        when(compressorMock.compress(any(byte[].class))).thenReturn(impressionPayload.toByteArray());
        when(compressorMock.decompress(any(byte[].class))).thenReturn(impressionPayload.toByteArray());
        impressionPayloadFormatterProto.setCompressor(compressorMock);

        String encodedString = impressionPayloadFormatterProto.formatToString(impressionPayload);
        Assert.assertNotNull(encodedString);
        Assert.assertTrue(encodedString.startsWith(impressionPayloadFormatterProto.getCurrentVersionPrefix()));

        ImpressionPayload decodedPayload = impressionPayloadFormatterProto.formatFromString(encodedString);
        Assert.assertTrue((decodedPayload.equals(impressionPayload)));
    }

    private ImpressionPayload prepareTestProto() {
        return ImpressionPayload.newBuilder()
                .setRequestId("test_req_id")
                .setSourceId(100L)
                .setBidTime(12345L)
                .setSite("amazon.com")
                .setChannelId(99L)
                .build();
    }
}
