package com.a9.creativefetchurl.common;

import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.NoOpEncryptor;
import com.a9.creativefetchurl.proto.VueBidContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

public class VueBidContextFormatterProtoTest {

    private VueBidContextFormatterProto vueBidContextFormatterProto;

    @Before
    public void setUp() throws Exception {
        vueBidContextFormatterProto = new VueBidContextFormatterProto();
        vueBidContextFormatterProto.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void testFormatFromStringWithUnsupportedVersion() {
        Assert.assertNull(vueBidContextFormatterProto.formatFromString("vue_encodedString"));
    }

    @Test(expected = AaxUrlProtoParsingException.class)
    public void testFormatFromStringException() {
        vueBidContextFormatterProto.formatFromString("vuev1_encodedString");
    }

    @Test
    public void testFormatToStringAndFormatFromStringSuccess() {
        VueBidContext vueBidContext = prepareVueTestProto();
        String encodedString = vueBidContextFormatterProto.formatToString(vueBidContext);
        Assert.assertNotNull(encodedString);
        Assert.assertTrue(encodedString.startsWith(vueBidContextFormatterProto.getCurrentVersionPrefix()));

        VueBidContext decodedBidContext = vueBidContextFormatterProto.formatFromString(encodedString);
        Assert.assertTrue((decodedBidContext.equals(vueBidContext)));
    }

    private VueBidContext prepareVueTestProto() {
        return VueBidContext.newBuilder()
                .setVideoApi(1)
                .setDomain("www.amazon.com.au")
                .setDeviceId("device123")
                .setEventProcessingFlowType(2)
                .addAllVendors(Arrays.asList(1, 2, 3))
                .setCtaurl("https://cta.example.com")
                .build();
    }
}