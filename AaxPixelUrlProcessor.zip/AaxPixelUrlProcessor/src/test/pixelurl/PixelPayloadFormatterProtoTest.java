package pixelurl;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;

import com.a9.common.NoOpEncryptor;
import com.a9.pixelurl.common.PixelPayloadFormatterProto;
import com.a9.pixelurl.proto.PixelPayload;
import com.a9.pixelurl.proto.SecureId;
import com.a9.pixelurl.proto.EEXSupplyInfo;

import java.util.Base64;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;


public class PixelPayloadFormatterProtoTest {
    private PixelPayloadFormatterProto pixelPayloadFormatterProto;
    
    @Before
    public void setup() {
        pixelPayloadFormatterProto = new PixelPayloadFormatterProto();
        pixelPayloadFormatterProto.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void encryptAndDecryptStringFromFullPayload() {
        String serializedProtoString = pixelPayloadFormatterProto.formatToString(getFullPayload());
        Assert.assertNotNull(serializedProtoString);
        Assert.assertEquals(pixelPayloadFormatterProto.getCurrentVersionPrefix(), serializedProtoString.substring(0, pixelPayloadFormatterProto.getCurrentVersionPrefix().length()));

        PixelPayload payloadDeserialized = pixelPayloadFormatterProto.formatFromString(serializedProtoString);
        Assert.assertEquals("abc", payloadDeserialized.getSecureId().getRequestId());
        Assert.assertEquals("xyz", payloadDeserialized.getSlotBid().getBidId());
        Assert.assertEquals("123", payloadDeserialized.getSlotBid().getAdInfo().getAdId());
        Assert.assertEquals("456", payloadDeserialized.getSlotBid().getAdInfo().getCreativeId());
        Assert.assertEquals(400L, payloadDeserialized.getSlotBid().getNetworkId());
        Assert.assertEquals("123", payloadDeserialized.getEexSupplyInfo().getAppId());
        Assert.assertEquals("456", payloadDeserialized.getEexSupplyInfo().getAppVersion());
    }

    @Test
    public void testFormatFromString_backwardCompatible_v0() {
        String LEGACY_VERSION_PREFIX = PixelPayloadFormatterProto.PIXELPAYLOAD_PROTO_VERSION_V0;
        PixelPayload testProto = getFullPayload();
        String encoded = formatToStringLegacy(testProto, LEGACY_VERSION_PREFIX);

        Assertions.assertNotNull(encoded);
        Assertions.assertTrue(encoded.startsWith(LEGACY_VERSION_PREFIX));
        Assertions.assertFalse(encoded.startsWith(pixelPayloadFormatterProto.getCurrentVersionPrefix()));

        PixelPayload payloadDeserialized = pixelPayloadFormatterProto.formatFromString(encoded);
        Assert.assertEquals("abc", payloadDeserialized.getSecureId().getRequestId());
        Assert.assertEquals("xyz", payloadDeserialized.getSlotBid().getBidId());
        Assert.assertEquals("123", payloadDeserialized.getSlotBid().getAdInfo().getAdId());
        Assert.assertEquals("456", payloadDeserialized.getSlotBid().getAdInfo().getCreativeId());
        Assert.assertEquals(400L, payloadDeserialized.getSlotBid().getNetworkId());
        Assert.assertEquals("123", payloadDeserialized.getEexSupplyInfo().getAppId());
        Assert.assertEquals("456", payloadDeserialized.getEexSupplyInfo().getAppVersion());

        String encodedFromDecoded = pixelPayloadFormatterProto.formatToString(testProto);
        Assertions.assertNotNull(encodedFromDecoded);
        Assertions.assertTrue(encodedFromDecoded.startsWith(pixelPayloadFormatterProto.getCurrentVersionPrefix()));
        
    }
    
    private PixelPayload getFullPayload() {
        SecureId secureId = SecureId.newBuilder()
                                    .setRequestId("abc")
                                    .setSourceId("1200").build();
        
        PixelPayload.SlotBid slotBid = PixelPayload.SlotBid.newBuilder().setBidId("xyz").setNetworkId(400L)
                                                           .setAdInfo(PixelPayload.SlotBid.AdInfo.newBuilder().setAdId("123").setCreativeId("456"))
                                                           .build();

        EEXSupplyInfo eexSupplyInfo = EEXSupplyInfo.newBuilder().setAppId("123").setAppVersion("456").build();
        return PixelPayload.newBuilder()
                           .setSecureId(secureId)
                           .setSlotBid(slotBid)
                           .setEexSupplyInfo(eexSupplyInfo).build();
    }

    @Test
    public void encryptAndDecryptStringForIncompletePayload() {
        PixelPayload payload = PixelPayload.newBuilder().setSecureId(SecureId.newBuilder().setRequestId("edf").build()).build();
        String serializedProtoString = pixelPayloadFormatterProto.formatToString(payload);
        Assert.assertNotNull(serializedProtoString);
        Assert.assertEquals(pixelPayloadFormatterProto.getCurrentVersionPrefix(), serializedProtoString.substring(0, pixelPayloadFormatterProto.getCurrentVersionPrefix().length()));

        PixelPayload payloadDeserialized = pixelPayloadFormatterProto.formatFromString(serializedProtoString);
        Assert.assertEquals("edf", payloadDeserialized.getSecureId().getRequestId());
    }

    private String formatToStringLegacy(PixelPayload payloadProto, String versionPrefix) {
        if (StringUtils.equals(versionPrefix, pixelPayloadFormatterProto.getCurrentVersionPrefix())) {
            return pixelPayloadFormatterProto.formatToString(payloadProto);
        }

        if (StringUtils.equals(PixelPayloadFormatterProto.PIXELPAYLOAD_PROTO_VERSION_V0, versionPrefix)) {
            byte[] encryptedBytes = pixelPayloadFormatterProto.getEncryptor().encrypt(payloadProto.toByteArray());
            encryptedBytes = Base64.getUrlEncoder().encode(encryptedBytes); // v0_ used a encryptor with b64 bytes encoding embedded as part of encryption.
            return serializeForUrl(encryptedBytes, versionPrefix);
        }
        return null;
    }
}
