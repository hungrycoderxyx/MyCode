package com.a9.impressionurl.common;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;

import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.PayloadFormatter;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.common.compression.PayloadCompressor;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.impressionurl.proto.ImpressionPayload;
import com.google.common.collect.ImmutableSet;
import java.util.Base64;
import java.util.Collections;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ImpressionPayloadFormatterProto implements PayloadFormatter<ImpressionPayload> {

    public static final String PROTO_VERSION_V1 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("imv1c"));
    private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(PROTO_VERSION_V1);
    private Encryptor encryptor;
    private PayloadCompressor compressor;

    @Override
    public String formatToString(ImpressionPayload request) {
        byte[] protoBytes = compressor.compress(request.toByteArray());
        byte[] encryptedBytes = encryptor.encrypt(protoBytes);
        return serializeForUrl(encryptedBytes, getCurrentVersionPrefix());
    }

    @Override
    public ImpressionPayload formatFromString(String bidContextString) {

        String decodedUrl = urlDecode(bidContextString);
        String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(decodedUrl);
        if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
            return null;
        }

        String payloadProStringBase64URLSafe = decodedUrl.substring(extractedVersionPrefix.length());
        try {
            if (extractedVersionPrefix.equals(getCurrentVersionPrefix())) {
                byte[] decryptedBytes = encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe));
                decryptedBytes = compressor.decompress(decryptedBytes);
                return ImpressionPayload.parseFrom(decryptedBytes);
            }
            return null;
        } catch(Exception e) {
            throw new AaxUrlProtoParsingException("failed to format impression payload from string", e);
        }
    }

    @Override
    public String getCurrentVersionPrefix() {
        return PROTO_VERSION_V1;
    }
}
