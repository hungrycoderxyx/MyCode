package com.a9.clickurl.common;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;
import static org.apache.commons.codec.binary.Base64.decodeBase64;
import static org.apache.commons.codec.binary.Base64.isBase64;

import com.a9.clickurl.proto.AdspClickPayload;
import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.CompressiblePayloadFormatter;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.common.compression.PayloadCompressor;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.cpx.common.util.StringUtil;
import com.a9.log.CommonLogger;
import com.google.common.collect.ImmutableSet;

import java.util.Collections;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import java.util.Base64;

@Setter
@Getter
public class ClickPayloadFormatterProto implements CompressiblePayloadFormatter<AdspClickPayload> {

    private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());
    public static final String CLICK_PAYLOAD_V0 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("clv0"));
    public static final String CLICK_PAYLOAD_V1 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("clv1"));
    public static final String CLICK_PAYLOAD_V1_COMPRESSED = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("clv1c"));
    private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(CLICK_PAYLOAD_V0, CLICK_PAYLOAD_V1, CLICK_PAYLOAD_V1_COMPRESSED);
    private Encryptor encryptor;
    private PayloadCompressor compressor;

    @Override
    public String formatToString(AdspClickPayload payloadProto, boolean compress) {
        String currentVersion = compress ? getCurrentCompressedVersionPrefix() : getCurrentVersionPrefix();
        if (StringUtil.isNullOrEmpty(payloadProto.getVersionSignature())) {
            payloadProto = payloadProto.toBuilder().setVersionSignature(currentVersion).build();
        }

        byte[] protoBytes = payloadProto.toByteArray();
        if (compress) {
            protoBytes = compressor.compress(protoBytes);
        }
        byte[] encryptedBytes = encryptor.encrypt(protoBytes);
        return serializeForUrl(encryptedBytes, currentVersion);
    }

    @Override
    public String formatToString(AdspClickPayload payloadProto) {
        return formatToString(payloadProto, false);
    }

    /**
     * 
     * @param payloadString
     * @return: 
     * - AdspClickPayload object if parsing successfully.
     * - `null` if the given payload is not compatible with this formatter or is not a encoded click protobuf payload.
     * - Throw `ClickPayloadParsingException` if the given payload has passed the version and compatibility check, is determined to be a click Proto payload, but fail to be parsed into memory as Proto.
     */
    @Override
    public AdspClickPayload formatFromString(String payloadString) {
        if (StringUtil.isNullOrEmpty(payloadString)) {
            return null;
        }
        String urlDecodedPayload = urlDecode(payloadString);
        String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(urlDecodedPayload);
        if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
            return null;
        }

        String payloadProStringBase64URLSafe = urlDecodedPayload.substring(extractedVersionPrefix.length());
        try {
            byte[] decryptedBytes;
            if (CLICK_PAYLOAD_V1.equals(extractedVersionPrefix)) {
                decryptedBytes = encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe));
            } else if (CLICK_PAYLOAD_V1_COMPRESSED.equals(extractedVersionPrefix)) {
                decryptedBytes = encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe));
                decryptedBytes = compressor.decompress(decryptedBytes);
            }
            else {
                byte[] urlB64DecodedPayload = decodeBase64(payloadProStringBase64URLSafe);
                if (isBase64(urlB64DecodedPayload)) { urlB64DecodedPayload = Base64.getUrlDecoder().decode(urlB64DecodedPayload); }
                decryptedBytes = encryptor.decrypt(urlB64DecodedPayload);
            }

            AdspClickPayload payload = AdspClickPayload.parseFrom(decryptedBytes);
            if (!payload.getVersionSignature().equals(extractedVersionPrefix)) {
                logger.info("Version violation: formatter is {}, payload is {}.", getCurrentVersionPrefix(), payload.getVersionSignature());
            }
            return payload;
        } catch(Exception e) {
            throw new AaxUrlProtoParsingException("failed to format click payload from string", e);
        }
    }
    @Override
    public String getCurrentVersionPrefix() {
        return CLICK_PAYLOAD_V1;
    }

    @Override
    public String getCurrentCompressedVersionPrefix() {
        return CLICK_PAYLOAD_V1_COMPRESSED;
    }
}
