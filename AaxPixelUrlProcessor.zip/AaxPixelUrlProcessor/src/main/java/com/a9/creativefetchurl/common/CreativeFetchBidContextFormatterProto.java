package com.a9.creativefetchurl.common;

import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.PayloadFormatter;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.creativefetchurl.proto.CreativeFetchBidContext;
import com.a9.log.CommonLogger;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;

import java.util.Collections;
import java.util.Set;


import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;
import java.util.Base64;

@Setter
@Getter
public class CreativeFetchBidContextFormatterProto implements PayloadFormatter<CreativeFetchBidContext>  {

    private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());
    public static final String PROTO_VERSION_V1 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("cfv1"));
    private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(PROTO_VERSION_V1);
    private Encryptor encryptor;

    @Override
    public String formatToString(CreativeFetchBidContext request) {
        byte[] encryptedBytes = encryptor.encrypt(request.toByteArray());
        return serializeForUrl(encryptedBytes, getCurrentVersionPrefix());
    }

    @Override
    public CreativeFetchBidContext formatFromString(String bidContextString) {

        String decodedUrl = urlDecode(bidContextString);
        String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(decodedUrl);
        if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
            return null;
        }

        String payloadProStringBase64URLSafe = decodedUrl.substring(extractedVersionPrefix.length());
        try {
            if (extractedVersionPrefix.equals(PROTO_VERSION_V1)) {
                return CreativeFetchBidContext.parseFrom(encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe)));
            }
            return null;
        } catch(Exception e) {
            throw new AaxUrlProtoParsingException("failed to format creative bidContext from string", e);
        }
    }

    @Override
    public String getCurrentVersionPrefix() {
        return PROTO_VERSION_V1;
    }
}
