package com.a9.pixelurl.common;

import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;

import java.util.Arrays;
import java.util.Base64;
import java.util.Set;

import com.a9.common.PayloadFormatter;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.log.CommonLogger;
import com.a9.pixelurl.proto.NiiPixelPayload;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableSet;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class NiiPixelPayloadFormatterProto implements PayloadFormatter<NiiPixelPayload> {
    private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());

    @VisibleForTesting
    public static final String NIIPIXELPAYLOAD_PROTO_VERSION_V0 = UrlProtoEncodingUtils.buildVersionPrefix(Arrays.asList("v0", "nii"));
    private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(NIIPIXELPAYLOAD_PROTO_VERSION_V0);
    private Encryptor encryptor;

    @Override
    public String formatToString(NiiPixelPayload payload) {
        byte[] encryptedBytes = encryptor.encrypt(payload.toByteArray());
        return UrlProtoEncodingUtils.serializeForUrl(encryptedBytes, getCurrentVersionPrefix());
    }

    @Override
    public NiiPixelPayload formatFromString(String payloadString) {
        String decodedUrl = urlDecode(payloadString);
        String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(decodedUrl);
        if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
            return null;
        }

        String payloadProStringBase64URLSafe = decodedUrl.substring(extractedVersionPrefix.length());
        try {
            NiiPixelPayload payload;
            payload = NiiPixelPayload.parseFrom(encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe)));
            return payload;
        } catch(Exception e) {
            logger.error("failed to format payload from string", e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getCurrentVersionPrefix() {
        return NIIPIXELPAYLOAD_PROTO_VERSION_V0;
    }
}
