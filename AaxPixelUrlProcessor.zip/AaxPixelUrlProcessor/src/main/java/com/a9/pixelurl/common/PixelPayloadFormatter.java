package com.a9.pixelurl.common;

import com.a9.common.PayloadFormatter;
import com.a9.pixelurl.proto.PixelPayload;

public interface PixelPayloadFormatter extends PayloadFormatter<PixelPayload> {
    String formatToString(PixelPayload request);

    PixelPayload formatFromString(String payload);
}
