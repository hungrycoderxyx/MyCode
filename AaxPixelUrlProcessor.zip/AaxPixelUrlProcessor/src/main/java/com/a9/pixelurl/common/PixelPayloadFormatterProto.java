package com.a9.pixelurl.common;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;
import static org.apache.commons.codec.binary.Base64.decodeBase64;
import static org.apache.commons.codec.binary.Base64.isBase64;

import com.a9.common.AaxUrlProtoParsingException;
import java.util.Base64;
import java.util.Collections;
import java.util.Set;

import com.a9.common.UrlProtoEncodingUtils;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.log.CommonLogger;
import com.a9.pixelurl.proto.PixelPayload;
import com.google.common.collect.ImmutableSet;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PixelPayloadFormatterProto implements PixelPayloadFormatter {
    private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());

    public static final String PIXELPAYLOAD_PROTO_VERSION_V0 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("v0"));
    public static final String PIXELPAYLOAD_PROTO_VERSION_V1 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("v1"));
    private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(PIXELPAYLOAD_PROTO_VERSION_V0, PIXELPAYLOAD_PROTO_VERSION_V1);
    private Encryptor encryptor;

    @Override
    public String formatToString(PixelPayload payload) {
        byte[] encryptedBytes = encryptor.encrypt(payload.toByteArray());
        return serializeForUrl(encryptedBytes, getCurrentVersionPrefix());
    }

    @Override
    public PixelPayload formatFromString(String payloadString) {
        String decodedUrl = urlDecode(payloadString);
        String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(decodedUrl);
        if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
            return null;
        }

        String payloadProStringBase64URLSafe = decodedUrl.substring(extractedVersionPrefix.length());
        try {
            PixelPayload payload;
            if (extractedVersionPrefix.equals(PIXELPAYLOAD_PROTO_VERSION_V1)) {
                payload = PixelPayload.parseFrom(encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe)));
            } else {
                byte[] urlB64DecodedPayload = decodeBase64(payloadProStringBase64URLSafe);
                if (isBase64(urlB64DecodedPayload)) { urlB64DecodedPayload = Base64.getUrlDecoder().decode(urlB64DecodedPayload); }
                payload = PixelPayload.parseFrom(encryptor.decrypt(urlB64DecodedPayload)); 
            }
            return payload;
        } catch(Exception e) {
            throw new AaxUrlProtoParsingException("failed to format pixel payload from string", e);
        }
    }

    @Override
    public String getCurrentVersionPrefix() {
        return PIXELPAYLOAD_PROTO_VERSION_V1;
    }
}
