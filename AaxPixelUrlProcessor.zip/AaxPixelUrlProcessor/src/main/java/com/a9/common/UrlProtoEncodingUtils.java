package com.a9.common;

import static com.a9.cpx.common.util.URLEncoderUTF8.urlEncode;

import java.util.Base64;
import java.util.List;
import java.util.Set;

import com.google.common.annotations.VisibleForTesting;

public class UrlProtoEncodingUtils {

    @VisibleForTesting
    public static final String VERSION_PREFIX_DELIMITER_CHAR = "-";
    @VisibleForTesting
    public static final String VERSION_PREFIX_TERMINATING_CHAR = "_";
    

    public static Boolean isCompatiblePayload(Set<String> supportedVersion, String extractedVersionPrefix) {
        return supportedVersion.contains(extractedVersionPrefix);
    }
    
    public static String buildVersionPrefix(List<String> versionPrefixParts) {
        return String.join(VERSION_PREFIX_DELIMITER_CHAR, versionPrefixParts) + VERSION_PREFIX_TERMINATING_CHAR;
    }

    public static String extractVersionPrefix(String payloadString) {
        if (payloadString.indexOf(VERSION_PREFIX_TERMINATING_CHAR) <= 0) {
            return "";
        }
        return payloadString.substring(0, payloadString.indexOf(VERSION_PREFIX_TERMINATING_CHAR) + 1);
    }

    public static String serializeForUrl(byte[] payloadBytes, String prefix) {
        return urlEncode(prefix + Base64.getUrlEncoder().withoutPadding().encodeToString(payloadBytes));
    }
}
