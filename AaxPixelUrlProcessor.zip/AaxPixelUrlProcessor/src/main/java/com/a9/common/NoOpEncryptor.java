package com.a9.common;

import com.a9.cpx.common.encrypt.Encryptor;
public class NoOpEncryptor implements Encryptor {
    @Override
    public byte[] encrypt(byte[] dataToEncrypt) {
        return dataToEncrypt;
    }

    @Override
    public byte[] decrypt(byte[] dataToDecrypt) {
        return dataToDecrypt;
    }

    @Override
    public String encrypt(String dataToEncrypt) {
        return dataToEncrypt;
    }

    @Override
    public String decrypt(String dataToDecrypt) {
        return dataToDecrypt;
    }
}
