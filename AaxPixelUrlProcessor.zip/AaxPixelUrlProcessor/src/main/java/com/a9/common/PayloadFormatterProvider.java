package com.a9.common;



public interface PayloadFormatterProvider<T> {
    String versionPrefixSeparator = "_";

    default PayloadFormatter<T> getPayloadFormatterByPayload(String payloadString) {
        return getPayloadFormatterByVersion(attemptGetVersionPrefix(payloadString));
    }
    PayloadFormatter<T> getPayloadFormatterByVersion(String version);
    
    default String attemptGetVersionPrefix(String payloadString) {
        int versionPrefixSeparatorIndex = payloadString.indexOf(versionPrefixSeparator);
        if (versionPrefixSeparatorIndex != -1) {
            return payloadString.substring(0, versionPrefixSeparatorIndex + 1);
        }
        return "";
    }
}
