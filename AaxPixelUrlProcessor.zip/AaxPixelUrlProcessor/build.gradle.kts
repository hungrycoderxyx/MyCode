plugins {
    java
    id("brazil-gradle")
    id("brazil-gradle-java-presets")
    id("com.google.protobuf")
}

brazilGradle {
    configureBasicDependencies()
    configureAnnotationProcessors()
}

tasks.withType<Test> {
    useJUnitPlatform()
}

sourceSets {
    main {
        java {
            srcDirs("src/main/java", "generated-src/main/java")
        }
        proto {
            srcDirs("src")
        }
    }
}


protobuf {
    protoc {
        path = "protoc"
    }

    generatedFilesBaseDir = "generated-src"
}

dependencies {
    brazilGradle.run().forEach { runtimeOnly(it) }
    brazilGradle.build().forEach { implementation(it) }
    brazilGradle.testrun().forEach { testImplementation(it) }
    brazilGradle.tool("Lombok").forEach {
        compileOnly(it)
        annotationProcessor(it)
        testAnnotationProcessor(it)
        testCompileOnly(it)
    }
}

tasks {
    clean {
        dependsOn("clean-generated")
    }

    build {
        dependsOn("clean-generated")
        mustRunAfter("clean-generated")
    }

    task("clean-generated", Delete::class) {
        group = "clean"
        description = "Remove generated sources"

        delete(fileTree("generated-sources"))
    }
}
