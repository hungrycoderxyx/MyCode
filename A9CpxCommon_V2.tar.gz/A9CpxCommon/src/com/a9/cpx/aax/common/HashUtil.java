package com.a9.cpx.aax.common;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.zip.CRC32;

public class HashUtil {

    /**
     * Hash the given input using MD5 algorithm. This algorithm is not recommended by InfoSec and hence deprecated
     * in favor of {@link #sha256(String)} utility. MD5 hash will be 32 hexadecimal digits irrespective of the input
     * text length.
     *
     * Refer : https://policy.amazon.com/standard/143
     *
     * @deprecated Instead use {@link #sha256(String)}
     * @param input raw text to be hashed
     * @return MD5 hashed text
     */
    @Deprecated
    public static String md5(String input) {
        try {
            return toHex(MessageDigest.getInstance("MD5").digest(input.getBytes(Charset.forName("UTF-8"))));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Couldn't find MD5", e);
        }
    }

    /**
     * Hash the given input using SHA-1 algorithm. This algorithm is not recommended by InfoSec and hence deprecated
     * in favor of {@link #sha256(String)} utility. SHA-1 hash will be 40 hexadecimal digits irrespective of the input
     * text length.
     *
     * Refer : https://policy.amazon.com/standard/143
     *
     * @deprecated Instead use {@link #sha256(String)}
     * @param input raw text to be hashed
     * @return SHA-1 hashed text
     */
    @Deprecated
    public static String sha1(String input) {
        try {
            return toHex(MessageDigest.getInstance("SHA-1").digest(input.getBytes(Charset.forName("UTF-8"))));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Couldn't find SHA1", e);
        }
    }

    /**
     * Hash the given input using SHA-256 algorithm. This algorithm is approved by InfoSec for any integrity usecases.
     * SHA-256 hash will be 64 hexadecimal digits irrespective of the input
     *
     * Refer : https://policy.amazon.com/standard/143
     *
     * @param input raw text to be hashed
     * @return SHA-256 hashed text
     */
    public static String sha256(String input) {
        return toHex(sha256Bytes(input));
    }

    /**
     * Hash the given input using SHA-256 algorithm and return byte array. This algorithm is approved by InfoSec for
     * any integrity usecases.
     *
     * Refer : https://policy.amazon.com/standard/143
     *
     * @param input raw text to be hashed
     * @return SHA-256 hash byte array
     */
    public static byte[] sha256Bytes(String input) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(input.getBytes(Charset.forName("UTF-8")));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Couldn't find SHA-256", e);
        }
    }

    /**
     * Hash the given input using CRC32 algorithm and return a long for change or error detection. This algorithm is NOT
     * approved by InfoSec for integrity verification. DO NOT use the algorithm where high level of security is required.
     *
     * Refer : https://policy.amazon.com/standard/143
     *
     * @param input raw text to be hashed
     * @return CRC-32 hash value
     */
    public static long crc32(String input) {
        CRC32 crc32 = new CRC32();
        crc32.update(input.getBytes(Charset.forName("UTF-8")));
        return crc32.getValue();
    }

    /**
     * Validate SHA-1 hash text format
     * @param input hashed text to be validated
     * @return true if input text is SHA-1 hash
     */
    public static boolean isValidSha1(String input)
	{
    	return input.matches("[a-fA-F0-9]{40}");
	}

    /**
     * Validate MD5 hash text format
     * @param input hashed text to be validated
     * @return true if input text is MD5 hash
     */
    public static boolean isValidMd5(String input)
	{
    	return input.matches("[a-fA-F0-9]{32}");
	}

    private static char[] hexDigits = new char[]{ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
    private static String toHex(byte[] digest) {
        StringBuilder result = new StringBuilder(digest.length >>> 1);
        for (byte b : digest) {
            result.append(hexDigits[(b & 0xF0)>>>4]);
            result.append(hexDigits[(b & 0x0F)]);
        }
        return result.toString();
    }
}
