/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common;

/**
 * Wrapping Exception.  This class is a <code>RuntimeException</code>
 * that is to be used only for wrapping other exceptions, particularly for
 * wrapping checked exceptions to be thrown out of contexts in which they
 * are not declared.
 * <p/>
 * This class purposely exposes only constructors that
 * provide another <code>Throwable</code>.
 * <p/>
 * In order to prevent inadvertent nesting of <code>WrappingException</code>
 * wrappers, this class class will detect if it is constructed to wrap another
 * instance of itself (<code>WrappingException</code>), and will extract the
 * underlying cause (one level, using <code>getCause()</code>) and wrap that
 * instead.
 */
public class WrappingException extends RuntimeException {

    /**
     * Construct with a message and throwable.
     *
     * @param message
     * @param t
     */
    public WrappingException(String message, Throwable t) {
        super(message, (t instanceof WrappingException) ? t.getCause() : t);
    }

    /**
     * Construct with a throwable.
     *
     * @param t
     */
    public WrappingException(Throwable t) {
        super((t instanceof WrappingException) ? t.getCause() : t);
    }
}
