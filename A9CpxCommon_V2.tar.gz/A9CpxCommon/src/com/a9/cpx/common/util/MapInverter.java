/*
 * Copyright (c) 2009  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.util;

import java.util.HashMap;
import java.util.Map;

public class MapInverter {

    private MapInverter() {
    }

    public static <K, V> Map<V, K> invert(Map<K, V> map) {
        Map<V, K> inverse = new HashMap<V, K>();
        for (Map.Entry<K, V> e : map.entrySet()) {
            inverse.put(e.getValue(), e.getKey());
        }
        return inverse;
    }
}
