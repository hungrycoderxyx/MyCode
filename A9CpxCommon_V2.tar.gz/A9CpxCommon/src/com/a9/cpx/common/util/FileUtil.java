/*
 * Copyright (c) 2007  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileUtil {

    /**
     * Make a hard link (Unix only).
     * <p/>
     * Implementation note:  This works by executing "/bin/ln" in a separate process.
     *
     * @param existingFile The name of the existing file to link to
     * @param newLink      The name of the new link to create.
     * @param force        If true the -f flag is used with /bin/ln, any existing link is removed. See ln(1)
     * @throws IOException          If the operation completes but fails
     * @throws InterruptedException If interrupted while wating for the process to complete
     */
    public static void makeHardLink(File existingFile, File newLink, boolean force) throws IOException, InterruptedException {
        String lnCommand = force ? "/bin/ln -f " : "/bin/ln ";
        String cmd = lnCommand + existingFile.getAbsolutePath() + " " + newLink.getAbsolutePath();

        Process proc = null;
        BufferedReader bR = null;
        try {
            proc = Runtime.getRuntime().exec(cmd);
            int rc = proc.waitFor();
            if (rc != 0) {
                StringBuffer errMsgBuf = new StringBuffer("Failed to create link named " + newLink + " to file " + existingFile + ", Error: ");
                if (proc != null) {

                    bR = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
                    String s;

                    while ((s = bR.readLine()) != null) {
                        errMsgBuf.append(s);
                        errMsgBuf.append("\n");
                    }


                }

                throw new IOException(errMsgBuf.toString());
            }
        }
        finally {
            if (proc != null) {
                if (bR != null) {
                    IOUtil.silentCloseReader(bR);
                }
                IOUtil.silentCloseStream(proc.getInputStream());
                IOUtil.silentCloseStream(proc.getOutputStream());
                IOUtil.silentCloseStream(proc.getErrorStream());
            }

        }
    }


}
