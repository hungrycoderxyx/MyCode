/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * Subclass of {@link java.util.concurrent.LinkedBlockingQueue} that overrides the {@link
 * java.util.concurrent.BlockingQueue#offer} method.  Normally this would not be desirable, but {@link
 * java.util.concurrent.ThreadPoolExecutor} uses <code>offer()</code> and this makes sure it will actually block rather
 * than letting the queue grow unbounded or throwing {@link java.util.concurrent.RejectedExecutionException}.
 */
public class FullyBlockingQueue<E> extends LinkedBlockingQueue<E> {
    public FullyBlockingQueue(int capacity) {
        super(capacity);
    }

    /**
     * Blocking version of the offer method.
     * <p/>
     * Note: ignores <code>InterruptedException</code>
     *
     * @param o object to enqueue.
     * @return true (after blocking until the element can be placed on the queue)
     */
    public boolean offer(E o) {
        while (true) {
            try {
                put(o);
                return true;
            } catch (InterruptedException e) {
                //
            }
        }
    }
}
