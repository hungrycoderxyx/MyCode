/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

import com.a9.cpx.common.WrappingException;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.Map;

public class ExceptionUtil {

    private ExceptionUtil() {
    }

    /**
     * Rethrow a generic throwable in an appropriate unchecked form.
     * @param t a <code>Throwable</code> to rethrow.
     */
    public static void rethrow(Throwable t) {
        if (t instanceof Error)
            throw (Error) t;
        else if (t instanceof RuntimeException)
            throw (RuntimeException) t;
        else
            throw new WrappingException(t);
    }
	
	public static String getStackTrace(Throwable t) {
		StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        t.printStackTrace(pw);
        pw.flush();
        sw.flush();
        return sw.toString();
	}

    public static Map<String,Object> toMap(Throwable t) {
        Map<String,Object> ret = GenericFactory.newLinkedHashMap();

        if (t != null) {
            ret.put("type", t.getClass().getCanonicalName());
            ret.put("message", t.getMessage());
            ret.put("stackTrace", getStackTrace(t));
            if (t.getCause() != null) {
                ret.put("cause", toMap(t.getCause()));
            }
        }

        return ret;
    }

}
