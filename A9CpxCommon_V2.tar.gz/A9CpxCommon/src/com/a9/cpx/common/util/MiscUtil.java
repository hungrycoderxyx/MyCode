/*
 * Copyright (c) 2009  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 * @author Ilya Lipkind
 */


package com.a9.cpx.common.util;

public class MiscUtil {
    public static long cantorPairing(long k1, long k2) {
        return (k1 + k2)*(k1 + k2 + 1) / 2 + k2;
     }

    public static int hash64to32(long key) {
        //now map from 64 bits to 32
        key = (~key) + (key << 18); // key = (key << 18) - key - 1;
        key = key ^ (key >>> 31);
        key = key * 21; // key = (key + (key << 2)) + (key << 4);
        key = key ^ (key >>> 11);
        key = key + (key << 6);
        key = key ^ (key >>> 22);
        return (int) key;
     }
}
