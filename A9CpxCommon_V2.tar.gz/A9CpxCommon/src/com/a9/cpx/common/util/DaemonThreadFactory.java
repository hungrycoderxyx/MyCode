/**
 * 
 */
package com.a9.cpx.common.util;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * This {@link ThreadFactory} ensures that threads created from it are daemon
 * threads (in order to avoid having to deal with shutdown delay issues).
 * 
 * @author florent
 */
public class DaemonThreadFactory implements ThreadFactory {
	private final String prefix;
	private final AtomicInteger threadNumber = new AtomicInteger(1);
	
	public DaemonThreadFactory(String prefix) {
		this.prefix = prefix;
	}

	public DaemonThreadFactory() {
		this.prefix = "";
	}

	public Thread newThread(Runnable r) {
        final Thread t = Executors.defaultThreadFactory().newThread(r);
        t.setDaemon(true);
        t.setName(prefix + "#" + threadNumber.getAndIncrement() + "-" + t.getName());
        return t;
	}

}
