/*
 * Copyright (c) 2010  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/**
 * URLEncoder fixed to UTF-8 character encoding.
 * <p/>
 * The implementation uses <code>java.net.URLEncoder</code> but catches
 * <code>UnsupportedEncodingException</code> and wraps it as a
 * <code>RuntimeException</code>.   Because the Java Language Specification requires
 * standard JVMs to support UTF-8, an <code>UnsupportedEncodingException</code> should not
 * actually occur in practice with UTF-8.
 * <p/>
 * Callers, however, should take care that UTF-8 is the appropriate character encoding to
 * apply.  HTML 4.0 recommends the use of UTF-8 encoding for URLs/URIs, however HTTP 1.1
 * specifies a default character set of ISO-8859-1 for content and provides no
 * specification of default character set for URL/URIs.
 */
public class URLEncoderUTF8 {

    public static String urlEncode(String v) {
        try {
            return URLEncoder.encode(v, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // should not occur
            throw new RuntimeException(e);
        }
    }

    public static String urlDecode(String v) {
        try {
            return URLDecoder.decode(v, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // should not occur
            throw new RuntimeException(e);
        }
    }
}
