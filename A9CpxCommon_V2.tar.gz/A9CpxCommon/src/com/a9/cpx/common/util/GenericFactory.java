package com.a9.cpx.common.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class GenericFactory {
	public static <K, V> HashMap<K,V> newHashMap() {
		return new HashMap<K,V>();
	}
	public static <K, V> HashMap<K,V> newHashMap(final int initialCapacity) {
		return new HashMap<K,V>(initialCapacity);
	}
	public static <K, V> LinkedHashMap<K,V> newLinkedHashMap() {
		return new LinkedHashMap<K,V>();
	}
	public static <E> ArrayList<E> newArrayList() {
		return new ArrayList<E>();
	}
	public static <E> ArrayList<E> newArrayList(final int initialCapacity) {
		return new ArrayList<E>(initialCapacity);
	}
	public static <E> LinkedList<E> newLinkedList() {
		return new LinkedList<E>();
	}
	public static <E> HashSet<E> newHashSet() {
		return new HashSet<E>();
	}
	public static <E> HashSet<E> newHashSet(E... values) {
	    HashSet<E> set = new HashSet<E>();
	    for (E value: values) {
	        set.add(value);
	    }
	    return set;
	}
	public static <E> HashSet<E> newHashSet(final int initialCapacity) {
		return new HashSet<E>(initialCapacity);
	}
	public static <E> TreeSet<E> newTreeSet() {
		return new TreeSet<E>();
	}
	public static <K, V> ConcurrentMap<K,V> newConcurrentHashMap() {
		return new ConcurrentHashMap<K,V>();
	}
	public static <K, V> ConcurrentMap<K,V> newConcurrentHashMap(int initialCapacity) {
		return new ConcurrentHashMap<K,V>(initialCapacity);
	}
	public static <K, V> ConcurrentMap<K,V> newConcurrentHashMap(int initialCapacity,
            float loadFactor, int concurrencyLevel) {
		return new ConcurrentHashMap<K,V>(initialCapacity,loadFactor,concurrencyLevel);
	}
    public static <E> TreeSet<E> newTreeSet(Comparator<E> comparator) {
        return new TreeSet<E>(comparator);
    }
}
