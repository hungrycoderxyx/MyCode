/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class CalendarUtil {
    public static final TimeZone GMT_TIMEZONE = TimeZone.getTimeZone("GMT");

    // inhibit construction
    private CalendarUtil() {

    }

    /**
     * Calculate the beginning of the day represented by the given date (UTC) in the
     * specified timezone.
     *
     * @param dateUTC date in UTC
     * @param tz      time zone
     * @return a <code>Calendar</code> rerpesting the beginning of that day in the that
     *         time zone.
     */
    public static Calendar beginningOfDay(Date dateUTC, TimeZone tz) {
        // Get calendar representing the beginning of the current day in
        // the accrual time zone.
        Calendar cal = Calendar.getInstance(tz);
        if (dateUTC != null) cal.setTime(dateUTC);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }

    /**
     * Get a calendar representing the end of (last millisecond in) the day containing the
     * specified date.
     *
     * @param dateWithinDay a date within the day of interest
     * @param tz            the timezone to use for establishing the corresponding
     *                      calendar
     * @return a calendar representing the end of the day containing the specified date.
     */
    public static Calendar endOfDay(Date dateWithinDay, TimeZone tz) {
        // Get calendar representing the beginning of the current day in
        // the accrual time zone.
        Calendar cal = Calendar.getInstance(tz);
        if (dateWithinDay != null) cal.setTime(dateWithinDay);

        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);
        return cal;
    }
    
    /**
     * Calculate the beginning of the current day in a specified time zone.
     * <p/>
     * Equivalent to calling <code>beginningOfDay(null,tz)</code>.
     *
     * @param tz the time zone
     * @return a calendar representing the beginning of the current day in the specified
     *         time zone.
     */
    public static Calendar beginningOfCurrentDay(TimeZone tz) {
        return beginningOfDay(null, tz);
    }

    /**
     * Add specified number of days to the given date in the specified timezone.
     *
     * @param dateUTC date in UTC
     * @param tz      time zone
     * @param numDays number of days
     * @return a <code>Calendar</code> representing <code>numDays</code> later of than the
     *         given date in the specified time zone.
     */
    public static Calendar addDays(Date dateUTC, TimeZone tz, int numDays) {
        Calendar cal = getCalendar(dateUTC, tz);
        cal.add(Calendar.DAY_OF_MONTH, numDays);
        return cal;
    }


    /**
     * Get a calendar representing the beginning of the month containing the specified
     * date.
     *
     * @param date a date
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the beginning of the month containing the specified
     *         date.
     */
    public static Calendar beginningOfMonth(Date date, TimeZone tz) {
        Calendar cal = getCalendar(date, tz);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }

    /**
     * Get a calendar representing the end of the month (final millisecond within the
     * month) containing the specified date.
     *
     * @param date a date
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the end of the month containing the specified
     *         date.
     */
    public static Calendar endOfMonth(Date date, TimeZone tz) {
        Calendar cal = beginningOfFollowingMonth(date, tz);
        cal.add(Calendar.SECOND, -1);
        cal.set(Calendar.MILLISECOND, 999);
        return cal;
    }

    /**
     * Get a calendar representing the specified date plus the specified number of
     * calendar months.
     *
     * @param date   a date
     * @param tz     the timezone to use for establishing the corresponding calendar
     * @param months the number of months to add
     * @return a calendar representing the specified date plus the specified number of
     *         calendar months.
     */
    public static Calendar addMonths(Date date, TimeZone tz, int months) {
        Calendar cal = getCalendar(date, tz);
        cal.add(Calendar.MONTH, months);
        return cal;
    }

    /**
     * Get a calendar representing the specified date in the specified timezone.
     *
     * @param date a date
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the specified date in the specified timezone.
     */
    public static Calendar getCalendar(Date date, TimeZone tz) {
        Calendar cal = Calendar.getInstance(tz);
        cal.setTime(date);
        return cal;
    }

    /**
     * Get a calendar representing the specified timestamp in the specified timezone.
     *
     * @param timestamp a UNIX timestamp
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the specified date in the specified timezone.
     */
    public static Calendar getCalendar(long timestamp, TimeZone tz) {
        Calendar cal = Calendar.getInstance(tz);
        cal.setTimeInMillis(timestamp);
        return cal;
    }

    /**
     * Get a calendar representing the beginning of the month following the month
     * containing the specified date.
     *
     * @param date a date
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the beginning of the month following the month
     *         containing the specified date.
     */
    public static Calendar beginningOfFollowingMonth(Date date, TimeZone tz) {
        return beginningOfMonth(addMonths(date, tz, 1).getTime(), tz);
    }

    /**
     * Get a calendar representing the beginning of the month preceding the month
     * containing the specified date.
     *
     * @param date a date
     * @param tz   the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the beginning of the month following the month
     *         containing the specified date.
     */
    public static Calendar beginningOfPriorMonth(Date date, TimeZone tz) {
        return beginningOfMonth(addMonths(date, tz, -1).getTime(), tz);
    }

    /**
     * Get a calendar representing the beginning of the day that follows the day
     * containing the specified date.
     *
     * @param date     a date
     * @param timeZone the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the beginning of the day that follows the day
     *         containing the specified date.
     */
    public static Calendar beginningOfFollowingDay(Date date, TimeZone timeZone) {
        return beginningOfDay(addDays(date, timeZone, 1).getTime(), timeZone);
    }

    /**
     * Get a calendar representing the end of (last millisecond in) the day that precedes
     * the day containing the specified date.
     *
     * @param date     a date
     * @param timeZone the timezone to use for establishing the corresponding calendar
     * @return a calendar representing the end of (last millisecond in) the day that
     *         precedes the day containing the specified date.
     */
    public static Calendar endOfPriorDay(Date date, TimeZone timeZone) {
        return endOfDay(addDays(date, timeZone, -1).getTime(), timeZone);
    }

    /**
     * Get a Calendar representing the beginning of (first millisecond within) the hour
     * containing the specified date in the specified timezone.
     *
     * @param date     the date
     * @param timeZone the timezone.
     * @return a calendar representing the beginning of the hour containing the specified
     *         date in the specified timezone.
     */
    public static Calendar beginningOfHour(Date date, TimeZone timeZone) {
        Calendar c = Calendar.getInstance(timeZone);
        c.setTimeInMillis(date.getTime());
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }


    /**
     * Get a Calendar representing the end of (last millisecond within) the hour
     * containing the specified date in the specified timezone.
     *
     * @param date     the date
     * @param timeZone the timezone.
     * @return a calendar representing the beginning of the hour containing the specified
     *         date in the specified timezone.
     */
    public static Calendar endOfHour(Date date, TimeZone timeZone) {
        Calendar c = CalendarUtil.beginningOfFollowingHour(date,timeZone);
        c.add(Calendar.MILLISECOND, -1);
        return c;
    }

    /**
     * Get a Calendar representing the beginning of (first millisecond within) the hour
     * containing the specified date in the specified timezone.
     *
     * @param date     the date
     * @param timeZone the timezone.
     * @return a calendar representing the beginning of the hour following the hour
     *         containing the specified date in the specified timezone.
     */
    public static Calendar beginningOfFollowingHour(Date date, TimeZone timeZone) {
        Calendar c = Calendar.getInstance(timeZone);
        c.setTimeInMillis(date.getTime());
        c.add(Calendar.HOUR, 1);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    /**
     * Get a Calendar representing the end of (last millisecond within) the hour preceding
     * the hour containing the specified date in the specified timezone.
     *
     * @param date     the date
     * @param timeZone the timezone.
     * @return a calendar representing the beginning of the hour containing the specified
     *         date in the specified timezone.
     */
    public static Calendar endOfPriorHour(Date date, TimeZone timeZone) {
        Calendar c = beginningOfHour(date, timeZone);
        c.add(Calendar.MILLISECOND, -1);
        return c;
    }

    /**
     * Get the number of calendar days between c1 and c2, where the two calendars have the
     * same time zone. Here the result 0 means that the two calendars represent times on
     * the same day, the result 1 means that they represent times on consecutive days, and
     * so forth.
     * <p/>
     * This uses a formula that works across daylight saving time boundaries, but does not
     * take leap seconds into account; for typical inputs this will not affect the
     * outcome.
     * <p/>
     *
     * @param c1 a time represented by a calendar
     * @param c2 a time represented by a calendar
     * @return the number of calendar days between c1 and c2.  The value returned is
     *         independent of the order of c1 and c2.
     */
    public static long daysBetween(Calendar c1, Calendar c2) {
        if (!c1.getTimeZone().getID().equals(c2.getTimeZone().getID())) {
            throw new IllegalArgumentException("The two calendars do not have the same time zone.");
        }
        if (c1.before(c2)) {
            return getJavaEpochDay(c2) - getJavaEpochDay(c1);
        } else {
            return getJavaEpochDay(c1) - getJavaEpochDay(c2);
        }
    }

    /**
     * Get the number of calendar days between d1 and d2, taken in the specified
     * timezone's rules.  The result 0 means that the two dates represent times on the
     * same day, the result 1 means that they represent times on consecutive days, and so
     * forth.
     * <p/>
     * This uses a formula that works across daylight saving time boundaries, but does not
     * take leap seconds into account; for typical inputs this will not affect the
     * outcome.
     *
     * @param d1 d1 a date
     * @param d2 d2 a date
     * @param tz tz a timeZone
     * @return the number of calendar days between the two dates, taken in the specified
     *         time zone.
     */
    public static long daysBetween(Date d1, Date d2, TimeZone tz) {
        return daysBetween(getCalendar(d1, tz), getCalendar(d2, tz));
    }

    /**
     * Get the Java Epoch day number, being the ordinal of the calendar day containing the
     * specified Calendar time since the beginnning of the Java/Unix Epoch (January 1,
     * 1970 00:00:00.000 UTC).  This computes the ordinal for the local time with offsets
     * provided by the <code>Calendar</code> provided.  It uses an approximation that does
     * not take leap seconds into account.
     *
     * @param c a calendar
     * @return the "Java Epoch" day number of the day.
     */
    private static long getJavaEpochDay(Calendar c) {
        long offset = c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET);
        return (long) Math.floor((double) (c.getTime().getTime() + offset) / 86400000D);
    }


    /**
     * Get a calendar from a date in numeric yyyymmdd format.
     *
     * @param yyyymmdd date in yyyymmdd format
     * @param timeZone timeZone in which to interpret date
     * @return a Calendar representing the beginning of this date.
     */
    public static Calendar fromYYYYMMDD(int yyyymmdd, TimeZone timeZone) {
        int year = yyyymmdd / 10000;
        int month = (yyyymmdd % 10000) / 100;
        int date = yyyymmdd % 100;
        Calendar c = Calendar.getInstance(timeZone);
        c.set(year, month - 1, date, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    /**
     * Convert a calendar to a numeric yyyymmdd format date.  This effectively truncates
     * to the day.
     *
     * @param c a calendar
     * @return the date corresponding to the calendar in yyyymmdd format.
     */
    public static int toYYYYMMDD(Calendar c) {
        return (c.get(Calendar.YEAR) * 10000) + ((c.get(Calendar.MONTH) + 1) * 100) + c.get(Calendar.DAY_OF_MONTH);
    }


    /**
     * Get a calendar from a date in numeric yyyymmdd format.
     *
     * @param yyyymmddhh date in yyyymmdd format
     * @param timeZone   timeZone in which to interpret date
     * @return a Calendar representing the beginning of this date.
     */
    public static Calendar fromYYYYMMDDHH(int yyyymmddhh, TimeZone timeZone) {
        int year = yyyymmddhh / 1000000;
        int month = (yyyymmddhh % 1000000) / 10000;
        int day = (yyyymmddhh % 10000) / 100;
        int hour = (yyyymmddhh % 100);
        Calendar c = Calendar.getInstance(timeZone);
        c.set(year, month - 1, day, hour, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    /**
     * Convert a calendar to a numeric yyyymmdd format date.  This effectively truncates
     * to the day.
     *
     * @param c a calendar
     * @return the date corresponding to the calendar in yyyymmdd format.
     */
    public static int toYYYYMMDDHH(Calendar c) {
        return (c.get(Calendar.YEAR) * 1000000) + ((c.get(Calendar.MONTH) + 1) * 10000) + c.get(Calendar.DAY_OF_MONTH) * 100 + c.get(Calendar.HOUR_OF_DAY);
    }

    /**
     * Get a calendar from its year, month, and day component.
     *
     * @param year the year of the date
     * @param month the month of the date
     * @param day the day of the date
     * @param timeZone timeZone in which to interpret date
     * @return a Calendar representing the beginning of this date.
     */
    public static Calendar fromYearMonthDay(int year, int month, int day, TimeZone timeZone) {
        Calendar c = Calendar.getInstance(timeZone);
        c.set(year, month - 1, day, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    /**
     * Function to return the first of the dates.
     * @param date1
     * @param date2
     * @return
     */
    public static Date minDate(Date date1, Date date2) {
    	return (date1.getTime() < date2.getTime()) ? date1 : date2;
    }

    /**
     * Function to return the first of the dates.
     * @param date1
     * @param date2
     * @return
     */
    public static Date maxDate(Date date1, Date date2) {
    	return (date1.getTime() > date2.getTime()) ? date1 : date2;
    }
}
