/*
 * Copyright (c) 2010  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Set;
import java.util.regex.Pattern;

public class StringUtil {
    
    /**
     *  Return a string that contains all the list components as strings
     *  separated by the specified separator. No escaping of the separator
     *  is performed in this method. (TODO: implement escaping of separator.)
     *
     * @param iterable iterator over the list to convert to a separated string
     * @param separator the string separator between elements
     * @return a concatenated string of the list elements
     */
    public static String join(Iterable<?> iterable, String separator) {
      StringBuffer buf = new StringBuffer();

      if (separator == null) {
          separator = "\n";
      }

      String sep = "";
      for (Object o : iterable) {
          buf.append(sep).append(o.toString());
          sep = separator;
      }

      return buf.toString();
    }

    /**
     * Checks if string is null or empty.
     * @param s string to check.
     * @return true if and only if s is null or empty.
     */
    public static boolean isNullOrEmpty(String s) {
        return s == null || s.length() == 0;
    }

    /**
     * Format given text as Javascript comment and append it to
     * the given buffer safely.
     *
     * @param sb buffer to append to.
     * @param comment comment text.
     */
    public static void appendJavascriptCommentToBuffer(StringBuilder sb, String comment) {
        if (! isNullOrEmpty(comment)) {
            BufferedReader br = new BufferedReader(new StringReader(comment));
            for (;;) {
                String line;
                try {
                    line = br.readLine();
                } catch (IOException e) {
                    throw new RuntimeException("Couldn't read from StringReader: " + e, e);
                }
                if (line == null)
                    break;
                sb.append("// ").append(line).append("\n");
            }
        } else {
            sb.append("// \n");
        }
    }


    private static Set<String> javascriptReservedWords = GenericFactory.newHashSet();

    // From http://www.ecma-international.org/publications/files/ECMA-ST/Ecma-262.pdf (Section 7.6)
    // Excludes support for Unicode Escape Sequence in identifier and <ZWNJ> <ZWJ>
    private static Pattern javascriptIdentifierPattern = Pattern.compile("[$_\\p{L}][$_\\p{L}\\p{Digit}\\p{Pc}\\p{Nd}\\p{Mc}\\p{Mn}]*");
    static {
        javascriptReservedWords.addAll(Arrays.asList("break", "do", "instanceof", "typeof",
            "case", "else", "new", "var",
            "catch", "finally", "return", "void",
            "continue", "for", "switch", "while",
            "debugger", "function", "this", "with",
            "default", "if", "throw",
            "delete", "in", "try",
            "class", "enum", "extends", "super",
            "const", "export", "import",
            "implements", "let", "private", "public", "yield",
            "interface", "package", "protected", "static",
            "null", "true", "false"));
    }

    public static boolean isJavascriptIdentifierValid(String s) {

        if (javascriptReservedWords.contains(s)) return false;
        return javascriptIdentifierPattern.matcher(s).matches();
    }
}
