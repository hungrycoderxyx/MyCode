/*
 * Copyright (c) 2010  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.util;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Collection;

public class URLUtil {

    /**
     * Takes a given base URL and appends parameters to it.
     * Parameters are represented as a collection of Pair<String,String>.
     * This method assumes parameters have been properly URL-encoded already; no further encoding is performed.
     *
     * @param baseUrl  base URL.
     * @param parameters parameters (already URL-encoded).
     * @return string representation of URL with new parameters appended.
     * @throws java.net.MalformedURLException if given base URL is malformed.
     */
    public static String appendEncodedParametersToUrl(String baseUrl, Collection<Pair<String,String>> parameters) throws MalformedURLException {
        try {
            return addParametersInternal(baseUrl, parameters, null);
        } catch (UnsupportedEncodingException e) {
            // we shouldn't get here since we are not actually encoding anything.
            throw new RuntimeException(e);
        }
    }

    /**
     * Takes a given base URL and appends parameters to it.
     * Parameters are represented as a collection of Pair<String,String>.
     * This method assumes parameters have been properly URL-encoded already; no further encoding is performed.
     *
     * @param baseUrl  base URL.
     * @param parameters parameters (already URL-encoded).
     * @param encoding encoding to use for URL encoding.
     * @return string representation of URL with new parameters appended.
     * @throws java.net.MalformedURLException if given base URL is malformed.
     * @throws java.io.UnsupportedEncodingException if specified encoding is not supported.
     */
    public static String encodeAndAppendParametersToUrl(String baseUrl, Collection<Pair<String,String>> parameters, String encoding) throws MalformedURLException, UnsupportedEncodingException {
        return addParametersInternal(baseUrl, parameters, encoding);
    }


    private static String addParametersInternal(String baseUrl, Collection<Pair<String, String>> parameters, String encoding) throws MalformedURLException, UnsupportedEncodingException {
        URL url = new URL(baseUrl);

        if (parameters != null && ! parameters.isEmpty()) {

            StringBuilder sb = new StringBuilder(baseUrl);

            String parameterSeparator;

            if (StringUtil.isNullOrEmpty(url.getQuery())) {

                if (baseUrl.endsWith("?")) {
                    parameterSeparator = "";
                } else {
                    parameterSeparator = "?";
                }

            } else {

                parameterSeparator = "&";
            }

            for (Pair<String,String> pair : parameters) {

                sb.append(parameterSeparator);
                sb.append(encodeStringAsNecessary(pair.getFirst(), encoding));
                sb.append('=');
                sb.append(encodeStringAsNecessary(pair.getSecond(), encoding));

                parameterSeparator = "&";
            }

            return sb.toString();

        } else {

            return baseUrl;
        }
    }

    private static String encodeStringAsNecessary(String toEncode, String encoding) throws UnsupportedEncodingException {

        if (encoding == null) {
            return toEncode;
        }

        return URLEncoder.encode(toEncode, encoding);
    }
}
