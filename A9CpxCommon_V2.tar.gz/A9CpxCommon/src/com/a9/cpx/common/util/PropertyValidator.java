/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

/**
 * Helper utility that can be used by beans to validate property value settings during
 * initialization.
 */
public class PropertyValidator {

    /**
     * Check that the property value is non-null otherwise, throw an <code>IllegalStateException</code> with a message
     * indicating the specified property name must be set.
     *
     * @param propValue
     * @param propName
     */
    public static void checkNonNull(Object propValue, String propName) {
        if (propValue == null) {
            throw new IllegalStateException("The " + propName + " property must be set.");
        }
    }

    /**
     * Check that the property value lies within the specified range.
     * @param value           the property value
     * @param min             minimum value
     * @param minInclusive    whether the minimum value is included in the range
     * @param max             maximum value
     * @param maxInclusive    whether the maximimum value is included in the range
     * @param propName        the name of the property
     */
    public static void checkRange(long value, Long min, boolean minInclusive, Long max, boolean maxInclusive, String propName)  {
        if ( (min != null && ((minInclusive && value < min) || (!minInclusive && value <= min))) ||
             (max != null && ((maxInclusive && value > max) || (!maxInclusive && value >= max))) ) {
            throw new IllegalStateException("The value of " + propName + " must be " +
                ((min != null) ? (minInclusive ? "at least " : "greater than ") + min : "") +
                ((min != null && max != null) ? " and " : "") +
                ((max != null) ? (maxInclusive ? "at most " : "less than ") + max : ""));
        }
    }

}
