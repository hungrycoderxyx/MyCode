package com.a9.cpx.common.util;

import com.a9.cpx.common.WrappingException;

import java.io.*;

public class IOUtil {

    private static final int DEFAULT_BUFFER_SIZE = 16384;
    public static String newline = System.getProperty("line.separator");

    public static void copyStream(InputStream is, OutputStream os) throws IOException {
        copyStream(is,os,DEFAULT_BUFFER_SIZE,false);
    }

    public static void copyStream(InputStream is, OutputStream os, int bufferSize) throws IOException {
        copyStream(is,os,bufferSize,false);
    }

    public static void copyStream(InputStream is, OutputStream os, int bufferSize, boolean closeStreams) throws IOException {
        InputStream bis = null;
        OutputStream bos = null;
        int bytesRead = 0;

        byte [] buffer = new byte [bufferSize];
        try {
            bis = new BufferedInputStream(is);
            bos = new BufferedOutputStream(os);

            while((bytesRead = bis.read(buffer)) >= 0 ) {
                bos.write(buffer,0,bytesRead);
            }
            bos.flush();
        } finally {
            if (closeStreams) {
                IOUtil.silentCloseStream(bis);
                IOUtil.silentCloseStream(bos);
            }
        }
    }

    public static void silentCloseStream(InputStream is) {
        if (is != null) {
            try { is.close(); } catch (Exception e) { /* ignore cleanup exception */ }
        }
    }

    public static void silentCloseStream(OutputStream os) {
        if (os != null) {
            try { os.close(); } catch (Exception e) { /* ignore cleanup exception */ }
        }
    }

    public static void silentCloseReader(Reader r) {
        if (r != null) {
            try { r.close(); } catch (Exception e) { /* ignore cleanup exception */ }
        }
    }

    public static void silentCloseWriter(Writer w) {
        if (w != null) {
            try { w.close(); } catch (Exception e) { /* ignore cleanup exception */ }
        }
    }

    public static String reader2String(Reader reader) throws IOException {
        if (reader == null) return null;
        StringBuilder result = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                result.append(line + newline);
            }
        } finally {
            IOUtil.silentCloseReader(reader);
        }
        return result.toString();
    }

    public static String dumpFileToString(String fileName) throws IOException {
        if (fileName == null) throw new IllegalArgumentException("File name cannot be null");
        File file = new File(fileName);
        InputStream ins = null;
        OutputStream outs = null;
        try {
            ins = new BufferedInputStream(new FileInputStream(file));
            outs = new ByteArrayOutputStream();
            copyStream(ins, outs);
            return outs.toString();
        } catch (IOException e) {
            throw new WrappingException(e);
        } finally {
            IOUtil.silentCloseStream(ins);
            IOUtil.silentCloseStream(outs);
        }
    }

    public static void dumpStringToFile(String str, String fileName) {
        if (fileName == null) throw new IllegalArgumentException("File name cannot be null");
        File file = new File(fileName);
        InputStream ins = null;
        OutputStream outs = null;
        try {
            ins = new ByteArrayInputStream(str.getBytes());
            outs = new BufferedOutputStream(new FileOutputStream(file));
            copyStream(ins, outs);
        } catch (IOException e) {
            throw new WrappingException(e);
        } finally {
            IOUtil.silentCloseStream(ins);
            IOUtil.silentCloseStream(outs);
        }
    }

}
