package com.a9.cpx.common.util;

import java.sql.Connection;
import java.sql.Statement;

import com.a9.cpx.common.WrappingException;

/*
 * This class contains static utility methods to assist in database
 * cleanup. They generally should be used in finally clauses after
 * database operations.
 */
public class DBCleanup {

    // The following convenience methods capture the most common
    // use cases for resource cleanup in the presence of exception
    //
    // Typical usage pattern without transaction demarcation:
    //
    //
    //    Exception currExc = null;
    //    Connection conn = null;
    //    Statement stmt = null;
    //
    //    try {
    //
    //        conn = (Connection) getDataSource().getConnection();
    //        stmt = conn.createStatement();
    //        stmt.executeUpdate("insert into ...." );
    //    } catch (Exception e) {
    //        currExc = e;
    //        // log if desirable
    //    } finally {
    //        DataAccessLayerDBCleanup.closeStatementAndConnection(currExc, stmt);
    //    }
    //

    public static void closeStatementAndConnection(Exception currentException,
            Statement stmt, Connection conn) {
        Exception cleanupException = currentException;
        cleanupException = closeStatementStoreEx(stmt, cleanupException);
        cleanupException = closeConnectionStoreEx(conn, cleanupException);
        ifExThrow(cleanupException);
    }

    /*
     * These routines perform close() operations on objects and store the
     * return exception.  They are structured this way to allow chaining
     * of these calls while keeping track of the original exception (if any) 
     * for later throwing.
     *
     *
     */

    /**
     * Calls stmt.close() and handles exception chaining as follows:
     * 
     * If currentException is not null, it returns the same exception passed in, 
     * otherwise if an exception is thrown within the body of the routine, it is
     * returned. (Alternative implementation could be to provide a special Exception
     * subclass which carries a list of accumulated exceptions)
     * 
     * @param stmt JDBC statement to close
     * @param currentException if not null, contains the exception being propagated
     * @return exception to propagate up the call stack
     */
    public static Exception closeStatementStoreEx(Statement stmt,
            Exception currentException) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (Exception ex) {
            if (currentException == null) {
                currentException = ex;
            }

        }
        return currentException;
    }

    /**
     * if conn is not null, calls conn.close() and handles exception chaining as follows:
     * 
     * If currentException is not null, it returns the same exception passed in, 
     * otherwise if an exception is thrown within the body of the routine, it is
     * returned. (Alternative implementation could be to provide a special Exception
     * subclass which carries a list of accumulated exceptions)
     * 
     * @param conn JDBC connection to close
     * @param currentException if not null, contains the exception being propagated
     * @return exception to propagate up the call stack
     */
    public static Exception closeConnectionStoreEx(Connection conn,
            Exception currentException) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            if (currentException == null) {
                currentException = ex;
            }
            // else keep the original exception
        }
        return currentException;
    }

    /**
     * If currentException is not null, throws WrappingException which contains
     * currentException
     * To be used as a shorthand in resource cleanup finally {} blocks
     * where exception needs to be propagated
     * 
     * @param currentException
     */
    public static void ifExThrow(Exception currentException) {
        if (currentException != null) {
            throw new WrappingException(currentException);
        }
    }

}
