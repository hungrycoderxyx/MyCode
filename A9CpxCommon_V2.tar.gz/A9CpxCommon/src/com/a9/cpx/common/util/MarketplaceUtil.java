package com.a9.cpx.common.util;

import java.util.TimeZone;

/*
 * This is a temp class to handle marketplace related mapping. This implementation should be 
 * replaced when we extend marketplace notion to billing components.
 */
public class MarketplaceUtil {
	public static TimeZone getTimeZoneForMarketplace(long marketplaceId) {
		// temporary 
		return TimeZone.getTimeZone("America/Los_Angeles");
	}
	


}
