package com.a9.cpx.common.util;

public class CallSiteHelper {
    private static final StackTraceElement fallbackStackTraceElement = new Throwable().getStackTrace()[0];
    
    public static StackTraceElement getCallSite() {
        Throwable t = new Throwable();
        
        for (StackTraceElement ste: t.getStackTrace()) {
            if (!ste.getClassName().equals(CallSiteHelper.class.getName())) {
                return ste;
            }
        }
        return fallbackStackTraceElement;
    }
    public static String getCallingClassName() {
        return getCallSite().getClassName();
    }
    
    public static void main(String[] args) {
        System.err.println("main(): "+ getCallSite());
        System.err.println("static class member : "+ Test.callSite);
    }
    
    static private class Test {
        static StackTraceElement callSite = CallSiteHelper.getCallSite();
    }
    
    
}
