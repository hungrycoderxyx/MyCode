/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

public class ClassLoaderUtil {
    private ClassLoaderUtil() {

    }

    /**
     * Get the current thread's context class loader or, if no context classloader is set,
     * then the loader that loaded the class <code>myClass</code>, supplied as a parameter.
     * @param myClass   Class of the caller, as supplied by the caller.
     * @return the classloader, selected as described.
     */
    public static ClassLoader getContextOrMyClassLoader(Class myClass) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        return (cl != null) ? cl : myClass.getClassLoader();
    }

   
}
