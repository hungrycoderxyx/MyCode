/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */

package com.a9.cpx.common.util;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;


/**
 * Implements a lock table with "expirable" locks
 *  
 */


public class LockTable {
    
    // helper object to keep lock creation time
    private static class LockInfo {
        long time = System.currentTimeMillis();
    }
    
    // if entry for an object is present in this map, 
    // the object is considered locked
    // the implementation is dependent on atomicity of
    // ConcurrentMap behavior for correct locking semantics
    private ConcurrentMap<Object,LockInfo> lockTable = 
        new ConcurrentHashMap<Object,LockInfo>();
    
    
    /**
     * Attempts to acquire lock that never expires
     * 
     * @param lockKey object for which lock is being acquired 
     * @return true if lock was acquired, false if object already has an existing lock
     */
    public boolean tryLock(Object lockKey) {
        return tryLock(lockKey,Long.MAX_VALUE);
    }

    /**
     * Attempts to acquire lock taking into account lock expiration 
     * 
     * @param lockKey object for which lock is being acquired 
     * @param lockExpirationTime time in milliseconds since lock creation after which lock
     *                           is considered expired and can be replaced with a new one
     * @return true if lock was acquired, false if object already has an existing  unexpired lock 
     */
    public boolean tryLock(Object lockKey, long lockExpirationTime) {
        LockInfo newLockInfo = new LockInfo();
        
        // atomically place the lock if does not exist
        LockInfo lastLockInfo = lockTable.putIfAbsent(lockKey,newLockInfo);
        if (lastLockInfo == null || lastLockInfo == newLockInfo) {
            return true;
        } else {
            if (System.currentTimeMillis() - lastLockInfo.time > lockExpirationTime) {
                // lock has been around for too long, replace it 
                return lockTable.replace(lockKey,lastLockInfo,newLockInfo);
            } else {
                return false;
            }
        }
    }
    
    /**
     * Removes lock (if any) associated with the lockKey argument
     * 
     * @param lockKey object for which lock is being released
     */
    public void releaseLock(Object lockKey) {
        lockTable.remove(lockKey);
    }
}
