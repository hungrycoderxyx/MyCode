/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.util;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Collection;


public class CastUtil {

    private CastUtil() {

    }

    public static <T> List<T> checkAndCast(List list, Class<T> c) {
        for (Object o : list) {
            if (! (c.isAssignableFrom(o.getClass()))) {
                throw new ClassCastException("List contains an element of type " + o.getClass().getName() +
                    " expected " + c.getName());
            }
        }
        // unchecked cast warning now, but we've checked.
        //noinspection unchecked
        return (List<T>) list;
    }

    public static <T> Set<T> checkAndCast(Set s, Class<T> c) {
        for (Object o : s) {
            if (! (c.isAssignableFrom(o.getClass()))) {
                throw new ClassCastException("Set contains an element of type " + o.getClass().getName() +
                    " expected " + c.getName());
            }
        }
        // unchecked cast warning now, but we've checked.
        //noinspection unchecked
        return (Set<T>) s;
    }

    public static <X,Y> Map<X,Y> checkAndCast(Map map, Class<X> keyClass, Class<Y> valueClass) {
        //noinspection unchecked
        for (Map.Entry<Object,Object> e : ((Map<Object,Object>) map).entrySet()) {
            if (!keyClass.isAssignableFrom(e.getKey().getClass())) {
               throw new ClassCastException("Map contains an element with key of type " + e.getKey().getClass().getName() +
                    " expected " + keyClass.getName());
            }
            if (!valueClass.isAssignableFrom(e.getValue().getClass())) {
               throw new ClassCastException("Map contains an element with key of type " + e.getValue().getClass().getName() +
                    " expected " + valueClass.getName());
            }
        }
        //noinspection unchecked
        return (Map<X,Y>) map;
    }

    public static <T> Collection<T> checkAndCast(Collection coll, Class<T> c) {
        for (Object o : coll) {
            if (! (c.isAssignableFrom(o.getClass()))) {
                throw new ClassCastException("Collection contains an element of type " + o.getClass().getName() +
                    " expected " + c.getName());
            }
        }
        // unchecked cast warning now, but we've checked.
        //noinspection unchecked
        return (Collection<T>) coll;        
    }
}
