package com.a9.cpx.common.util;

import amazon.platform.config.AppConfig;
import java.math.BigInteger;
import java.util.Random;

public class CFIDUtil
{
    /** returns a random number with exactly max digits*/
    public static int nextRandomNumber(int max)
    {
        if(max>9) throw new IllegalArgumentException("number of digits should not exceed 9");
        BigInteger ten = new BigInteger("10");
        int i = new Random().nextInt(ten.pow(max).intValue()-ten.pow(max-1).intValue()-1);
        return i + ten.pow(max-1).intValue();
    }

    /**
     * Create a new Customer Facing ID (CFID) using the AppConfig region identifier
     *
     * @return the CFID number
     */
    public static long createCfId()
    {
        return createCfId(REGION_ID);
    }

    /**
     * Create a new Customer Facing ID (CFID) using an integer region identifier
     *
     * @param regionId
     * @return the CFID number
     */
    public static long createCfId(int regionId)
    {
        int randomInt = new Random().nextInt(10);
        String str = String.valueOf(nextRandomNumber(9))
                   + String.format("0%d%02d", randomInt, regionId);
        return Long.parseLong(str);
    }

    /**
     * Format the given Customer Facing ID (CFID) as a string.
     * 
     * @param cfid
     * @return the formatted CFID.
     */
    public static String formatCFID(long cfid, String prefix)
    {
        String number = String.valueOf(cfid);
        int seq1 = 4;
        int seq3 = 5;
        int seq2 = number.length() - seq1 - seq3;
        if (seq2 < 0) {
            return number;
        }
        
        StringBuffer sb = new StringBuffer(prefix + "-");
        sb.append(number.substring(0, seq1));
        sb.append("-");
        sb.append(number.substring(seq1, seq1+seq2));
        sb.append("-");
        sb.append(number.substring(seq1+seq2));
        return sb.toString();
    }

    /**
     * Parse the given formatted Customer Facing ID (CFID).
     *  
     * @param formattedCFID
     * @return the CFID number
     */
    public static long parseCFID(String formattedCFID)
    {
        String number = formattedCFID.replaceAll("[ a-zA-Z\\-]", "");
        try {
            return Long.parseLong(number);
        }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException("Cannot convert '" + number + "' to long");
        }
    }

    public static final String REGION_ID_KEY = "CFIDRegionId";
    private static final int REGION_ID = AppConfig.findInteger(REGION_ID_KEY);
}
