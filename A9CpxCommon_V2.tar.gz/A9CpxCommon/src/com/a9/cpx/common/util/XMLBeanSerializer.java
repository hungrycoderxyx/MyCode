package com.a9.cpx.common.util;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

import com.a9.cpx.common.WrappingException;

/**
 * Utility to provide XML Bean serialization using java.beans.XMLEncoder and XMLDecoder.
 */
public class XMLBeanSerializer {

    public static String serialize(Object object) {
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            XMLEncoder encoder = new XMLEncoder(buffer);
            encoder.setPersistenceDelegate(BigDecimal.class, encoder.getPersistenceDelegate(Double.class));
            encoder.writeObject(object);
            encoder.close();
            return buffer.toString("UTF-8");
        } catch (UnsupportedEncodingException uex) {
            // Should never actually happen.
            throw new WrappingException(uex);
        }
    }

    public static Object deserialize(String xml) {
        try {
            ByteArrayInputStream buffer = new ByteArrayInputStream(xml.getBytes("UTF-8"));
            XMLDecoder decoder = new XMLDecoder(buffer);
            Object obj = decoder.readObject();
            decoder.close();
            return obj;
        } catch (UnsupportedEncodingException uex) {
            // Should never actually happen.
            throw new WrappingException(uex);
        }
    }

}
