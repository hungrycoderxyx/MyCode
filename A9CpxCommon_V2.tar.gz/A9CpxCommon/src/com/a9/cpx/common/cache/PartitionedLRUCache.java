/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */

package com.a9.cpx.common.cache;

/**
 * 
 * Provides thread-safe and concurrency-efficient LRU cache using PartitionedCache 
 * with LRUCache as partition type.
 * 
 */

public class PartitionedLRUCache<K,V>  extends PartitionedCache<K,V> {

    private int maxPartitionCapacity;
    
    public PartitionedLRUCache (int numOfPartitions, int maxCapacity) {
        
        // total of partitionCapacity must be at least maxCapacity
        // (relying on usual assumption that hashing is quite uniform)
        maxPartitionCapacity = (maxCapacity / numOfPartitions) + 1;
        super.initialize(numOfPartitions);
      
    }
    
    protected Cache<K,V> makeCachePartition() {
        return  new Cache<K,V>() { 
            
            private LRUCache<K,V> map = new LRUCache<K,V>(maxPartitionCapacity);
            
            public synchronized V get(K key) { 
                return map.get(key);
            }
            
            public synchronized void put(K key, V value) { 
                map.put(key,value); }
            
            public synchronized void remove(K key) { 
                map.remove(key); 
            }
        };
    }
}
