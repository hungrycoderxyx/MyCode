/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */

package com.a9.cpx.common.cache;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Provides thread-safe and low-contention cache by splitting a single map into a 
 * fixed set of partitions each of each is a separate map
 * Specific map implementation used by partitions is provided by overrideable 
 * method makeMapPartition(). Its default implementation simply returns
 * Collections.synchronizedMap(new HashMap<K, V>())
 */

public class PartitionedCache<K,V> implements Cache<K,V> {

    // note using explicit implementation type is essential as
    // we want to ensure O(1) access time for efficiency reasons

    protected ArrayList<Cache<K, V>> partitions;
    
    protected PartitionedCache() {
    }
    
    public PartitionedCache(int numOfPartitions) {
        initialize(numOfPartitions);
    }

    protected void initialize(int numOfPartitions) {
        partitions = new ArrayList<Cache<K, V>>(numOfPartitions);
        for (int i = 0; i < numOfPartitions; i++) {
            partitions.add(makeCachePartition());
        }
    }

    public V get(K key) {
        return partitions.get(getIndex(key)).get(key);
    }

    public void put(K key, V value) {
        partitions.get(getIndex(key)).put(key, value);
    }

    public void remove(K key) {
        partitions.get(getIndex(key)).remove(key);
    }

    protected Cache<K, V> makeCachePartition() {
        return new Cache<K,V>() {
            private Map<K,V> map = Collections.synchronizedMap(new HashMap<K, V>());

            public V get(K key) { return map.get(key); }

            public void put(K key, V value) { map.put(key,value); }

            public void remove(K key) { map.remove(key); }

        };
    }

    private int getIndex(K key) {
        // using long expansion to force unsigned interpretation
        int index = (int) (((long)hash(key.hashCode()) & 0x0000ffff) % partitions.size());
        return index;
    }

    /* The following function is borrowed from java.util.HashMap */

    /**
     * Returns a hash value for the specified object. In addition to the
     * object's own hashCode, this method applies a "supplemental hash
     * function," which defends against poor quality hash functions. This is
     * critical because HashMap uses power-of two length hash tables.
     * <p>
     * The shift distances in this function were chosen as the result of an
     * automated search over the entire four-dimensional search space.
     */
    private static int hash(Object x) {
        int h = x.hashCode();

        h += ~(h << 9);
        h ^= (h >>> 14);
        h += (h << 4);
        h ^= (h >>> 10);
        return h;
    }

}
