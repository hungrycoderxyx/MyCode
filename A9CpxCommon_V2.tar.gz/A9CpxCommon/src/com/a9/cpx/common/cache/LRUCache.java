/*
 * Copyright (c) 2005  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */


package com.a9.cpx.common.cache;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LRUCache.  A basic LRU cache implementation based on {@link java.util.LinkedHashMap}.
 * <p/>
 * <strong>Note:</strong> This class does not do syncrhonization by default.  Wrap it with
 * {@link java.util.Collections#synchronizedMap(java.util.Map)} for basic
 * synchronization.  We may have to provide a better implementation utilizing reader-writer
 * locking if contention becomes an issue.
 */
public class LRUCache<K,V> extends LinkedHashMap<K,V> {
    // Instance members
    private int maxCapacity;

    /**
     * Create the cache.
     *
     * @param initialMapSize initial map size (initial number of hash buckets in the hash map)
     * @param loadFactor     the load factor used to determine growth of the underlying map.
     * @param maxCapacity    the maximum size of the cache before eviction starts occurring
     */
    public LRUCache(int initialMapSize, float loadFactor, int maxCapacity) {
        super(initialMapSize, loadFactor, true);
        this.maxCapacity = maxCapacity;
    }

    /**
     * Create the cache.  Creates the cache with default values of the initial map size
     * and load factor.  The initial map size is computed as <code>maxCapacity/128</code>
     * but at least 16 (the fixed default that <code>LinkedHashMap</code> uses).  The load
     * factor used is <code>0.75F</code> which is also the fixed default that
     * <code>LinkedHashMap</code> uses.
     *
     * @param maxCapacity
     */
    public LRUCache(int maxCapacity) {
        this( Math.max(16, maxCapacity >> 7), 0.75F, maxCapacity);
    }


    /**
     * Determine whether the eldest entry should be removed.  This is called by
     * the superclass to determine whether the eldest entry should be removed.
     * This implementation returns true
     *
     * @param eldest the eldest entry
     * @return true whenever the current size of the cache exceeds the specified
     *         maximum capacity.
     * @see java.util.LinkedHashMap#removeEldestEntry(java.util.Map.Entry)
     */
    protected boolean removeEldestEntry(Map.Entry eldest) {
        return size() > maxCapacity;
    }

    /**
     * Get the maximum capacity that was specified for this cache.
     *
     * @return the maximum capacity specified for this cache.
     */
    public int getMaxCapacity() {
        return maxCapacity;
    }

    /**
     * Set the maximum capacity.  It is possible to set the maximum capacity
     * to a new value, but not smaller than the current size of the cache.
     * If the provided value is smaller than the current size, the current
     * size is used instead.
     *
     * @param maxCapacity
     */
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = Math.max(size(), maxCapacity);
    }
}
