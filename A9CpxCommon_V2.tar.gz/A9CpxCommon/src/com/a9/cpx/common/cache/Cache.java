/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */

package com.a9.cpx.common.cache;


/**
 * Provides general cache abstraction. 
 * 
 * A caller should not expect values added to the cache to be always present as
 * cached entries could be removed based on caching policies
 */

public interface Cache<K,V> {

    public V get(K key);

    public void put(K key, V value);

    public void remove(K key);
}
