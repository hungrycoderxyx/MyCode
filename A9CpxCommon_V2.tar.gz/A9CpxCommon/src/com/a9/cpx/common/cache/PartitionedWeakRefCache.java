/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */

package com.a9.cpx.common.cache;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;


/**
 * 
 * Provides thread-safe and concurrency-efficient cache using WeakReference so that
 * when memory pressure increases the content of it can be discarded
 * 
 */

public class PartitionedWeakRefCache<K,V>  extends PartitionedCache<K,V> {
    
    public PartitionedWeakRefCache (int numOfPartitions) {
        super(numOfPartitions);
    }

    protected Cache<K,V> makeCachePartition() {
        return new Cache<K,V> () {
            
            private Map<K,WeakReference<V>> map = 
                Collections.synchronizedMap(new WeakHashMap<K,WeakReference<V>>());
            
            public V get(K key) { 
                WeakReference<V> ref = map.get(key);
                
                if (ref != null) return ref.get();
                
                return null;
            }
            
            public void put(K key, V value) { 
                map.put(key,new WeakReference<V>(value)); }
            
            public void remove(K key) { 
                map.remove(key); 
            }
        };
    }
}
