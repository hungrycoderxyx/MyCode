package com.a9.cpx.common.metrics;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

public final class CryptoMetricsRegistry {
    private static final CryptoMetrics NOOP = new NoopCryptoMetrics();
    private static final AtomicReference<CryptoMetrics> REF = new AtomicReference<>(NOOP);

    private CryptoMetricsRegistry() {}

    public static CryptoMetrics get() {
        return REF.get();
    }

    public static void set(CryptoMetrics metrics) {
        REF.set(Objects.requireNonNull(metrics));
    }

    public static void install(CryptoMetrics metrics) {
        Objects.requireNonNull(metrics);
        REF.compareAndSet(NOOP, metrics); // idempotent "first one wins"
    }
}






