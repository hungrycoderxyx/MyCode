package com.a9.cpx.common.metrics;

public final class NoopCryptoMetrics implements CryptoMetrics {
    @Override public void decryptVersion(String version) {}
    @Override public void decryptFailure(String reason) {}
}
