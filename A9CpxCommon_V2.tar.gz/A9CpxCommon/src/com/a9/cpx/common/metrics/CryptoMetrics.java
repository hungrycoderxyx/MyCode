package com.a9.cpx.common.metrics;

public interface CryptoMetrics {
    void decryptVersion(String version);
    void decryptFailure(String reason);
}
