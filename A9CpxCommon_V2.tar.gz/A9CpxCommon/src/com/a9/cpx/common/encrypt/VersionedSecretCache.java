package com.a9.cpx.common.encrypt;

import com.amazonaws.secretsmanager.caching.SecretCacheConfiguration;
import com.amazonaws.secretsmanager.caching.cache.LRUCache;
import com.amazonaws.secretsmanager.caching.cache.SecretCacheItem;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;

import java.nio.ByteBuffer;

/**
 * Alternative version of com.amazonaws.secretsmanager.caching.cache.SecretCache
 * that exposes method to retrieve secret data other than the string (getSecretValue()).
 */
class VersionedSecretCache implements AutoCloseable {
    private final LRUCache<String, SecretCacheItem> cache;
    private final SecretCacheConfiguration config;
    private final AWSSecretsManager client;

    public VersionedSecretCache() {
        this(AWSSecretsManagerClientBuilder.standard());
    }

    public VersionedSecretCache(AWSSecretsManagerClientBuilder builder) {
        this(null == builder ? (AWSSecretsManager)AWSSecretsManagerClientBuilder.standard().build() : (AWSSecretsManager)builder.build());
    }

    public VersionedSecretCache(AWSSecretsManager client) {
        this((new SecretCacheConfiguration()).withClient(client));
    }

    public VersionedSecretCache(SecretCacheConfiguration config) {
        if (null == config) {
            config = new SecretCacheConfiguration();
        }

        this.cache = new LRUCache(config.getMaxCacheSize());
        this.config = config;
        this.client = config.getClient() != null ? config.getClient() : (AWSSecretsManager)AWSSecretsManagerClientBuilder.standard().build();
    }

    private SecretCacheItem getCachedSecret(String secretId) {
        SecretCacheItem secret = (SecretCacheItem)this.cache.get(secretId);
        if (null == secret) {
            this.cache.putIfAbsent(secretId, new SecretCacheItem(secretId, this.client, this.config));
            secret = (SecretCacheItem)this.cache.get(secretId);
        }
        return secret;
    }

    public GetSecretValueResult getSecretValue(String secretId) {
        SecretCacheItem secret = this.getCachedSecret(secretId);
        return secret.getSecretValue();
    }

    public String getSecretString(String secretId) {
        SecretCacheItem secret = this.getCachedSecret(secretId);
        GetSecretValueResult gsv = secret.getSecretValue();
        return null == gsv ? null : gsv.getSecretString();
    }

    public ByteBuffer getSecretBinary(String secretId) {
        SecretCacheItem secret = this.getCachedSecret(secretId);
        GetSecretValueResult gsv = secret.getSecretValue();
        return null == gsv ? null : gsv.getSecretBinary();
    }

    public boolean refreshNow(String secretId) throws InterruptedException {
        SecretCacheItem secret = this.getCachedSecret(secretId);
        return secret.refreshNow();
    }

    public void close() {
        this.cache.clear();
    }
}
