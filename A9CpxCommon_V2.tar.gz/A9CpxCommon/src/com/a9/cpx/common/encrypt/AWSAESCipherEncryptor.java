package com.a9.cpx.common.encrypt;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.secretsmanager.caching.SecretCacheConfiguration;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.annotations.VisibleForTesting;

public class AWSAESCipherEncryptor implements Encryptor, AutoCloseable {

    private static final Long SECRET_TTL = Duration.ofMinutes(60).toMillis();
    private static final String AES_GCM_MODE_NO_PADDING = "AES/GCM/NoPadding";
    private static final String AES = "AES";
    private static final int GCM_TAG_LENGTH = 16; // bytes
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    // Layout: "iv_" (3 bytes) || 12-byte IV || (ciphertext || tag, at least 1 byte)
    private static final int V2_PREFIX_LEN = 3;
    private static final int IV_LEN = 12;
    private static final int MIN_CT_TAG_LEN = 1;

    private VersionedSecretCache secretCache;
    private String secretArn;
    private String secretKeyName;
    private String ivKeyName;

    @VisibleForTesting
    public AWSAESCipherEncryptor(VersionedSecretCache secretCache, String secretArn, String secretKeyName, String ivKeyName) {
        this.secretCache = secretCache;
        this.secretArn = secretArn;
        this.secretKeyName = secretKeyName;
        this.ivKeyName = ivKeyName;
    }

    public AWSAESCipherEncryptor(AWSCredentialsProvider awsCredentialsProvider, String awsRegion, String secretArnTemplate, String secretKeyName, String ivKeyName) {
        SecretCacheConfiguration configuration = new SecretCacheConfiguration();
        configuration.setClient(AWSSecretsManagerClientBuilder.standard()
                .withRegion(awsRegion)
                .withCredentials(awsCredentialsProvider)
                .build());
        configuration.setCacheItemTTL(SECRET_TTL);

        this.secretCache = new VersionedSecretCache(configuration);
        this.secretArn = String.format(secretArnTemplate, awsRegion);
        this.secretKeyName = secretKeyName;
        this.ivKeyName = ivKeyName;
    }

    // ----------------- LEGACY ENCRYPT (UNCHANGED) -----------------

    @Override
    public String encrypt(String plainText) {
        try {
            GetSecretValueResult getSecretValueResult = getSecretValueResult(secretArn);
            Cipher cipher = initializeCipher(Cipher.ENCRYPT_MODE, getSecretValueResult.getSecretString());
            return Base64.getUrlEncoder().encodeToString(cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public byte[] encrypt(byte[] plainByte) {
        try {
            GetSecretValueResult getSecretValueResult = getSecretValueResult(secretArn);
            Cipher cipher = initializeCipher(Cipher.ENCRYPT_MODE, getSecretValueResult.getSecretString());
            return cipher.doFinal(plainByte);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public EncryptResult encryptWithMetadata(String plainText) {
        try {
            GetSecretValueResult getSecretValueResult = getSecretValueResult(secretArn);
            Cipher cipher = initializeCipher(Cipher.ENCRYPT_MODE, getSecretValueResult.getSecretString());
            return new EncryptResult(
                    Base64.getUrlEncoder().encodeToString(cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8))),
                    secretArn, getSecretValueResult.getVersionId());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ----------------- DECRYPT (LEGACY UNCHANGED + v2 AUTODETECT) -----------------

    @Override
    public String decrypt(String cipherText) {
        try {
            byte[] in = Base64.getUrlDecoder().decode(cipherText);
            GetSecretValueResult sv = getSecretValueResult(secretArn);
            String secretsJsonString = sv.getSecretString();

            if (isV2Envelope(in)) {
                // v2 decrypt-only path: key = UTF-8 bytes of secretKey; envelope has iv and (ct||tag)
                JsonNode secrets = OBJECT_MAPPER.readTree(secretsJsonString);
                byte[] key = secrets.get(secretKeyName).textValue().getBytes(StandardCharsets.UTF_8);
                SecretKeySpec keySpec = new SecretKeySpec(key, AES);

                final int ivOff = V2_PREFIX_LEN;
                final int ctOff = ivOff + IV_LEN;

                Cipher c = Cipher.getInstance(AES_GCM_MODE_NO_PADDING);
                c.init(Cipher.DECRYPT_MODE, keySpec, new GCMParameterSpec(128, in, ivOff, IV_LEN));
                byte[] plaintext = c.doFinal(in, ctOff, in.length - ctOff);
                return new String(plaintext, StandardCharsets.UTF_8);
            } else {
                // legacy path (unchanged)
                Cipher cipher = initializeCipher(Cipher.DECRYPT_MODE, secretsJsonString);
                return new String(cipher.doFinal(in), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public byte[] decrypt(byte[] cipherByte) {
        try {
            GetSecretValueResult sv = getSecretValueResult(secretArn);
            String secretsJsonString = sv.getSecretString();

            if (isV2Envelope(cipherByte)) {
                // v2 decrypt-only path
                JsonNode secrets = OBJECT_MAPPER.readTree(secretsJsonString);
                byte[] key = secrets.get(secretKeyName).textValue().getBytes(StandardCharsets.UTF_8);
                SecretKeySpec keySpec = new SecretKeySpec(key, AES);

                final int ivOff = V2_PREFIX_LEN;
                final int ctOff = ivOff + IV_LEN;

                Cipher c = Cipher.getInstance(AES_GCM_MODE_NO_PADDING);
                c.init(Cipher.DECRYPT_MODE, keySpec, new GCMParameterSpec(128, cipherByte, ivOff, IV_LEN));
                return c.doFinal(cipherByte, ctOff, cipherByte.length - ctOff);
            } else {
                // legacy path (unchanged)
                Cipher cipher = initializeCipher(Cipher.DECRYPT_MODE, secretsJsonString);
                return cipher.doFinal(cipherByte);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ----------------- HELPERS -----------------

    private static boolean isV2Envelope(byte[] in) {
        return in != null
                && in.length >= V2_PREFIX_LEN + IV_LEN + MIN_CT_TAG_LEN
                && in[0] == 'i' && in[1] == 'v' && in[2] == '_';
    }

    private GetSecretValueResult getSecretValueResult(String secretId) {
        return secretCache.getSecretValue(secretId);
    }

    /**
     * Legacy cipher init (UNCHANGED): parses the JSON, builds key/IV from UTF-8 bytes,
     * allocates a fresh Cipher, and init()s for the requested mode.
     */
    private Cipher initializeCipher(int cipherMode, String secretsJsonString)
            throws IOException, NoSuchPaddingException, NoSuchAlgorithmException,
            InvalidAlgorithmParameterException, InvalidKeyException {

        JsonNode secretsJson = OBJECT_MAPPER.readTree(secretsJsonString);
        String secretKey = secretsJson.get(secretKeyName).textValue();
        String ivKey = secretsJson.get(ivKeyName).textValue();

        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), AES);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * Byte.SIZE, ivKey.getBytes(StandardCharsets.UTF_8));

        Cipher cipher = Cipher.getInstance(AES_GCM_MODE_NO_PADDING);
        cipher.init(cipherMode, keySpec, gcmParameterSpec);
        return cipher;
    }

    @Override
    public void close() throws Exception {
        secretCache.close();
    }
}


