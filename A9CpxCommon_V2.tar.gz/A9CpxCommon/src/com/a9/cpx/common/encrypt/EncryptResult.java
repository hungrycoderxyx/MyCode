package com.a9.cpx.common.encrypt;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class EncryptResult {
    private String encryptedString;
    private String secretKeyId;
    private String secretKeyVersion;
}
