package com.a9.cpx.common.encrypt;

public interface Encryptor {

    default byte[] encrypt(byte[] dataToEncrypt) { throw new RuntimeException(); };
    default byte[] decrypt(byte[] dataToDecrypt) { throw new RuntimeException(); };

    default String encrypt(String dataToEncrypt) { throw new RuntimeException(); }
    default String decrypt(String dataToDecrypt) { throw new RuntimeException(); }
}
