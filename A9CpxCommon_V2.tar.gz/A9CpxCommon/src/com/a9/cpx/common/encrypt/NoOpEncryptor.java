package com.a9.cpx.common.encrypt;

public class NoOpEncryptor implements Encryptor {

    @Override
    public byte[] encrypt(byte[] dataToEncrypt) {
        return dataToEncrypt;
    }

    @Override
    public byte[] decrypt(byte[] dataToDecrypt) {
        return dataToDecrypt;
    }
}
