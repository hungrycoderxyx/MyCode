/*
 * Copyright (c) 2005 A9.com, Inc. or its affiliates
 * All Rights Reserved
 */
package com.a9.cpx.common.ds;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class NumberRangeMap {

    private final static String IP_ADDRESS_PARTS_SEPARATOR = "(\\.)";

    private final static String IP_ADDRESS_MASK_SEPARATOR = "/";

    private Interval root;

    class Interval {
        final private long upper;

        final private long lower;

        public boolean isContained(long value) {
            return lower <= value && value <= upper;
        }

        public Interval(long lower, long upper) {
            if (upper < lower) {
                throw new IllegalArgumentException("Lower " + lower
                        + " is not less then upper " + upper);
            }
            this.upper = upper;
            this.lower = lower;
        }

        public Interval(byte[] bytes, int subnetMask) {
            long val = convertBytesToLong(bytes);
            this.lower = val & (~subnetMask);
            this.upper = val | subnetMask;
        }

        public long getLower() {
            return lower;
        }

        public long getUpper() {
            return upper;
        }

        public String toString() {
            return ("lower: " + Long.toHexString(lower) + ", upper: " +
                    Long.toHexString(upper));
        }

        public boolean overlaps(long[] range) {
            if (range[1] < lower || range[0] > upper)
                return false;
            else
                return true;
        }
    }

    class IntervalSet extends Interval {
        final private Interval left;

        final private Interval right;

        IntervalSet(List<Interval> intervals, long lower, long upper,
                    int startIndex, int endIndex) {
            super(lower, upper);
            int size = endIndex - startIndex + 1;
            if (size <= 1) {
                throw new IllegalArgumentException(
                        "Cannot create interval based on indices from "
                                + startIndex + " to  " + endIndex);
            }
            if (size == 2) {
                left = intervals.get(startIndex);
                right = intervals.get(endIndex);
            } else if (size == 3) {
                left = intervals.get(startIndex);
                right = new IntervalSet(intervals, intervals
                        .get(startIndex + 1).getLower(), intervals
                        .get(endIndex).getUpper(), startIndex + 1, endIndex);
            } else {
                int endMiddleIndex = startIndex + size / 2;
                left = new IntervalSet(intervals, intervals.get(startIndex)
                        .getLower(), intervals.get(endMiddleIndex - 1)
                        .getUpper(), startIndex, endMiddleIndex - 1);
                right = new IntervalSet(intervals, intervals
                        .get(endMiddleIndex).getLower(), intervals
                        .get(endIndex).getUpper(), endMiddleIndex, endIndex);
            }
        }

        public boolean isContained(long value) {
            boolean isInside = super.isContained(value);
            return isInside ? left.isContained(value)
                    || right.isContained(value) : false;
        }

        public boolean overlaps(long[] range) {
            if (left.getLower() > range[1] || right.getUpper() < range[0])
                return false;
            else
                return (left.overlaps(range) || right.overlaps(range));
        }
    }

    class IntervalComparator implements Comparator<Interval> {

        public int compare(Interval o1, Interval o2) {
            return Long.valueOf(o1.getLower()).compareTo(o2.getLower());
        }

    }

    private void dump(List<Interval> intervals) {
        System.out.println("Dump Itervals===============================");
        for (Interval interval : intervals) {
            System.out.println("Lower: " + interval.getLower() + " Upper: "
                    + interval.getUpper() + " Range: "
                    + (interval.getUpper() - interval.getLower()));
        }
        System.out.println("End of dump ================================");
    }

    private void init(List<String> hostnamesOrIpAddresses) throws IOException {
        List<Interval> intervals = readConfiguration(hostnamesOrIpAddresses);
        processIntervals(intervals);
    }

    public void initFromIpAddresses(List<String> ipAddresses) {
        List<Interval> intervals = new LinkedList<Interval>();
        for (String ipAddress : ipAddresses) {
            intervals.add(parseAsIpAddress(ipAddress));
        }
        processIntervals(intervals);
    }

    private void processIntervals(List<Interval> intervals) {
        // dump(intervals);
        Collections.sort(intervals, new IntervalComparator());
        // dump(intervals);
        mergeOverlapped(intervals);
        // dump(intervals);
        int size = intervals.size();
        if (size == 0) {
            // Filter with nothing to filter
            // It might be required if we want to change filtering through JMX
            return;
        }
        root = (size == 1) ? intervals.get(0) : new IntervalSet(intervals,
                intervals.get(0).getLower(),
                intervals.get(size - 1).getUpper(), 0, size - 1);
    }

    private List<Interval> createIntervals(long[][] intervals) {
        List<Interval> iList = new ArrayList<Interval>(intervals.length);
        for (long[] bounds : intervals) {
            iList.add(new Interval(bounds[0], bounds[1]));
        }
        return iList;
    }

    private void initByIntervalList(long[][] intervals) throws IOException {
        processIntervals(createIntervals(intervals));
    }

    protected List<Interval> readConfiguration(List<String> hostnamesOrIpAddresses)
            throws IOException {
        List<Interval> intervals = new LinkedList<Interval>();
        for (String hostnameOrIpAddress : hostnamesOrIpAddresses) {
            intervals.add(convertHostnameOrIpToInterval(hostnameOrIpAddress));
        }
        return intervals;
    }

    private Interval convertHostnameOrIpToInterval(String hostnameOrIpAddress) {

        try {
            // TRY to consider the hostnameOrIpAddress string as a host name
            byte[] address = InetAddress.getByName(hostnameOrIpAddress).getAddress();
            return new Interval(address, 0);

        } catch (Exception e) {
            // It might be IP already
            return parseAsIpAddress(hostnameOrIpAddress);
        }
    }

    private List<Interval> mergeOverlapped(List<Interval> intervals) {
        for (int pos = 1; pos < intervals.size(); pos++) {
            Interval next = intervals.get(pos);
            Interval prev = intervals.get(pos - 1);
            if (prev.getUpper() >= next.getLower()) {
                // Intervals are overlapped
                if (prev.getUpper() >= next.getUpper()) {
                    // Next is completely included - we need to remove it
                } else {
                    // Next and current are overlapped - we need to merge them
                    intervals.set(pos - 1, new Interval(prev.getLower(), next
                            .getUpper()));
                }
                // next is not required any more
                intervals.remove(pos);
                // We need decrement pos - after repeating loop, pos will have
                pos--;
            }
        }
        return intervals;
    }

    public boolean isValid(String address) {
        if (root == null) {
            // Nothing to filter
            return true;
        }
        long value = convertIpToLong(address);
        return !root.isContained(value);
    }

    private Interval parseAsIpAddress(String address)
            throws IllegalArgumentException {
        String[] octets = splitIpToParts(address);
        // Check if CIDR notation is used
        String[] parts = octets[3].split(IP_ADDRESS_MASK_SEPARATOR);
        if (parts.length > 2) {
            throw new IllegalArgumentException("Invalid part in IP Address "
                    + address);
        }
        int subnetMask = 0;
        if (parts.length == 2) {
            octets[3] = parts[0];
            subnetMask = Integer.parseInt(parts[1]);
            if (subnetMask < 0 || subnetMask > 32)
                throw new IllegalArgumentException("SubnetMask for " + address +
                        " incorrectly specified.");
            subnetMask = ~(0xFFFFFFFF << (32 - subnetMask));
        }
        byte[] bytes = getIpBytes(octets);
        return new Interval(bytes, subnetMask);
    }

    private String[] splitIpToParts(String address) {
        String[] octets = address.split(IP_ADDRESS_PARTS_SEPARATOR);
        if (octets.length != 4) {
            throw new IllegalArgumentException("Not enough octets in address "
                    + address);
        }
        return octets;
    }

    private byte[] getIpBytes(String[] parts) throws IllegalArgumentException {
        if (parts == null || parts.length != 4) {
            throw new IllegalArgumentException("Invalid parts " + parts);
        }
        try {
            byte[] bytes = new byte[4];
            for (int i = 0; i < 4; i++) {
                int val = Integer.parseInt(parts[i]);
                if ((val > 255) || (val < 0)) {
                    throw new IllegalArgumentException(
                            "Invalid part in IP Address octet: " + val);
                }
                bytes[i] = (byte) val;
            }
            return bytes;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid octet in IP address "
                    + parts, e);
        }
    }

    private long convertBytesToLong(byte[] bytes) {
        long val = 0;
        for (byte ocstet : bytes) {
            val = val << 8;
            int unsigned = 0x000000FF & ocstet;
            val += unsigned;
        }
        return val;
    }

    public NumberRangeMap() {

    }

    public void setAddress(List<String> ipAddress) throws Exception {
        init(ipAddress);
    }

    //
    public void setIntervals(long[][] intervalList) throws Exception {
        initByIntervalList(intervalList);
    }

    public boolean containsAddress(long value) {
        if (root == null) {
            // Nothing to filter
            return false;
        }
        return root.isContained(value);
    }

    public boolean overlapsAddressRange(long[] range) {
        if (root == null) {
            // Nothing to filter
            return false;
        }
        return root.overlaps(range);
    }


    public boolean containsAddress(String address) {
        long value = convertIpToLong(address);
        return containsAddress(value);
    }

    private long convertIpToLong(String address) {
        String[] segments = splitIpToParts(address);
        byte[] bytes = getIpBytes(segments);
        return convertBytesToLong(bytes);
    }

    private void testInvalidFormats(String address) throws Throwable {
        try {
            long value = convertIpToLong(address);
            System.out.println(address + " converted to " + value
                    + " but should throw exception");
        } catch (IllegalArgumentException exception) {
            // as expected
        }
    }

    private void testValidFormats(long expectedValue, String address)
            throws Throwable {
        long value = convertIpToLong(address);
        if (value != expectedValue) {
            System.out.println(address + " converted to " + value
                    + " expected value:" + expectedValue);
        }
    }

    private void testValidAddress(String address) throws Throwable {
        if (!isValid(address)) {
            System.out.println(address + " should pass but was regected!!!");
        }
    }

    private void testInvalidAddress(String address) throws Throwable {
        if (isValid(address)) {
            System.out.println(address + " should be regected but pass !!!");
        }
    }

    public static void main(String[] args) throws Throwable {

        NumberRangeMap table = new NumberRangeMap();

        List<String> l = new ArrayList<String>();
        l.add("123.123.11.22");
        l.add("192.168.12.1/23");
        l.add("www.google.com");
        l.add("123.123.11.22");
        l.add("192.168.12.1/23");

        table.setAddress(l);

        table.testInvalidFormats("1");
        table.testInvalidFormats("1.2.3.");
        table.testInvalidFormats("1.2.3.4.5");
        table.testInvalidFormats("...");
        table.testInvalidFormats("256.1.1.1");
        table.testInvalidFormats("1.1.1.256");
        table.testInvalidFormats("1111.1.1.1");
        table.testInvalidFormats("1.1.1.1111");
        table.testInvalidFormats("1.1.1.1111");
        // Due to we know possible usage of the IP address parser, excessive
        // validation is not required for this specific usage

        table.testValidFormats(0x00000000L, "0.0.0.0");
        table.testValidFormats(0x00000001L, "0.0.0.1");
        table.testValidFormats(0x00000002L, "0.0.0.2");
        table.testValidFormats(0x00000004L, "0.0.0.4");
        table.testValidFormats(0x00000008L, "0.0.0.8");
        table.testValidFormats(0x0000000aL, "0.0.0.10");
        table.testValidFormats(0x0000000fL, "0.0.0.15");
        table.testValidFormats(0x00000010L, "0.0.0.16");
        table.testValidFormats(0x00000065L, "0.0.0.101");
        table.testValidFormats(0x000000ffL, "0.0.0.255");
        table.testValidFormats(0x0000ff00L, "0.0.255.0");
        table.testValidFormats(0x00ff0000L, "0.255.0.0");
        table.testValidFormats(0xffffffffL, "255.255.255.255");

        table.testInvalidAddress("123.123.11.22");
        table.testValidAddress("192.168.12.0");
        table.testInvalidAddress("192.168.12.1");
        table.testInvalidAddress("192.168.13.255");
        table.testValidAddress("192.168.14.0");

        NumberRangeMap.Interval interval = table.new Interval(new byte[]{103, 121, 2, 3}, 0xFFFF);
        System.out.println("interval :" + interval);
    }

}
