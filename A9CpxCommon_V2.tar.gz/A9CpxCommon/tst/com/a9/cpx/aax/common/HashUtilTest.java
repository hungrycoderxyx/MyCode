package com.a9.cpx.aax.common;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

public class HashUtilTest {

    private static final String TEST_INPUT = "test";
    private static final String TEST_INPUT_2 = "test1";
    private static final String TEST_INPUT_SHA256 = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08";
    private static final String EMPTY_TEXT_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    private static final String TEST_INPUT_SHA1 = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3";
    private static final String EMPTY_TEXT_SHA1 = "da39a3ee5e6b4b0d3255bfef95601890afd80709";
    private static final String TEST_INPUT_MD5 = "098f6bcd4621d373cade4e832627b4f6";
    private static final String EMPTY_TEXT_MD5 = "d41d8cd98f00b204e9800998ecf8427e";

    @Test
    public void testSHA1() {
        assertEquals(TEST_INPUT_SHA1, HashUtil.sha1(TEST_INPUT));
        assertEquals(EMPTY_TEXT_SHA1, HashUtil.sha1(""));
    }

    @Test
    public void testMD5() {
        assertEquals(TEST_INPUT_MD5, HashUtil.md5(TEST_INPUT));
        assertEquals(EMPTY_TEXT_MD5, HashUtil.md5(""));
    }

    @Test
    public void testSHA256() {
        assertEquals(TEST_INPUT_SHA256, HashUtil.sha256(TEST_INPUT));
        assertEquals(EMPTY_TEXT_SHA256, HashUtil.sha256(""));
    }

    @Test
    public void testSHA256Bytes() {
        assertArrayEquals(toBytes(TEST_INPUT_SHA256), HashUtil.sha256Bytes(TEST_INPUT));
        assertArrayEquals(toBytes(EMPTY_TEXT_SHA256), HashUtil.sha256Bytes(""));
    }

    @Test
    public void testCRC32() {
        assertEquals(HashUtil.crc32(TEST_INPUT), HashUtil.crc32(TEST_INPUT));
        assertNotSame(HashUtil.crc32(TEST_INPUT), HashUtil.crc32(TEST_INPUT_2));
    }

    @Test
    public void testIsValidSHA1() {
        assertTrue(HashUtil.isValidSha1(TEST_INPUT_SHA1));
        assertFalse(HashUtil.isValidSha1(TEST_INPUT));
    }

    @Test
    public void testIsValidMD5() {
        assertTrue(HashUtil.isValidMd5(TEST_INPUT_MD5));
        assertFalse(HashUtil.isValidMd5(TEST_INPUT));
    }

    private byte[] toBytes(String hexDigits) {
        byte[] bytes = new byte[hexDigits.length() / 2];
        for (int i = 0, j = 0; i < hexDigits.length(); i+=2) {
            bytes[j++] = (byte) Integer.parseInt(hexDigits.charAt(i) + "" + hexDigits.charAt(i + 1), 16);
        }
        return bytes;
    }
}
