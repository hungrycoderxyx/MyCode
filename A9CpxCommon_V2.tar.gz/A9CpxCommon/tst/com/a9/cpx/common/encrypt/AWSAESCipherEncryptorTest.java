package com.a9.cpx.common.encrypt;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AWSAESCipherEncryptorTest {

    private static final String SECRET_ARN = "secret-arn";
    private static final String SECRET_KEY_NAME = "secret-key";
    private static final String SECRET_KEY_VERSION = "V1";
    private static final String IV_KEY_NAME = "iv-key";

    // Produced fresh per test run to avoid provider IV-reuse checks across encrypt calls,
    // but stable within this test run (so legacy outputs remain deterministic for assertions).
    private String dynamicSecretsJson;

    // Obviously invalid - used to force failures
    private static final String INVALID_SECRET_CACHE_RESULT =
            "{\"" + SECRET_KEY_NAME + "\":\"this-is-an-invalid-secret-cache-key-aBcDeuHelHuheucbsuejWR==\",\"" + IV_KEY_NAME + "\":\"+LmidMw91ngfu938nHR/kd9MjhG/d8Kd73HnfoMeuth=\"}";

    private static final String PLAIN_PAYLOAD = "JDFqpaEPp9b24GfBaeWPc9YAAAGFOxFvJwEAAAJjBABOL0EgICAgICAgICAgICBOL0EgICAgICAgICAgICDCkRyf";

    @Mock private VersionedSecretCache secretCache;
    @Mock private GetSecretValueResult secretValueResult;
    @Mock private GetSecretValueResult invalidSecretValueResult;

    private AWSAESCipherEncryptor awsAesCipherEncryptor;

    @Before
    public void setUp() {
        // Generate fresh 16-byte ASCII key + 12-byte ASCII IV for this test run
        // (printable so UTF-8 byte length == char len; stable within test = deterministic legacy outputs).
        String keyStr = asciiRandom(16);
        String ivStr  = asciiRandom(12);

        dynamicSecretsJson = "{\"" + SECRET_KEY_NAME + "\":\"" + keyStr + "\",\"" + IV_KEY_NAME + "\":\"" + ivStr + "\"}";

        when(secretValueResult.getSecretString()).thenReturn(dynamicSecretsJson);
        when(invalidSecretValueResult.getSecretString()).thenReturn(INVALID_SECRET_CACHE_RESULT);
        when(secretValueResult.getVersionId()).thenReturn(SECRET_KEY_VERSION);
        when(secretCache.getSecretValue(any())).thenReturn(secretValueResult);

        awsAesCipherEncryptor = new AWSAESCipherEncryptor(secretCache, SECRET_ARN, SECRET_KEY_NAME, IV_KEY_NAME);
    }

    // ------------------------------------------------------------
    // Happy paths (legacy encryption -> legacy decrypt)
    // ------------------------------------------------------------

    @Test
    public void encryptWithMetaData() {
        EncryptResult encryptedPayload = awsAesCipherEncryptor.encryptWithMetadata(PLAIN_PAYLOAD);

        assertTrue(StringUtils.isNotBlank(encryptedPayload.getEncryptedString()));
        assertEquals(SECRET_KEY_VERSION, encryptedPayload.getSecretKeyVersion());
        assertEquals(SECRET_ARN, encryptedPayload.getSecretKeyId());

        // Under legacy (fixed IV from secrets) + stable secrets for this test, encrypt(...) is deterministic
        assertEquals(awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD), encryptedPayload.getEncryptedString());

        // Round-trip
        String decrypted = awsAesCipherEncryptor.decrypt(encryptedPayload.getEncryptedString());
        assertEquals(PLAIN_PAYLOAD, decrypted);
    }

    @Test
    public void encryptAndDecrypt() {
        String encryptedPayload = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
        assertTrue(StringUtils.isNotBlank(encryptedPayload));
        String decryptedPayload = awsAesCipherEncryptor.decrypt(encryptedPayload);
        assertEquals(PLAIN_PAYLOAD, decryptedPayload);
    }

    @Test
    public void legacyCiphertext_isNotV2EnvelopePrefix() {
        // Encrypt with legacy path and prove its Base64-decoded bytes DO NOT start with 'i','v','_'
        String encryptedPayload = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
        assertTrue(StringUtils.isNotBlank(encryptedPayload));

        byte[] decoded = Base64.getUrlDecoder().decode(encryptedPayload);
        boolean looksV2 = decoded.length >= 3 && decoded[0] == 'i' && decoded[1] == 'v' && decoded[2] == '_';
        assertTrue("Legacy ciphertext must not use v2 envelope (iv_ prefix)", !looksV2);
    }

    @Test
    public void encryptAndDecryptByte() {
        byte[] encryptedPayload = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8));
        assertTrue(encryptedPayload.length > 0);
        byte[] decryptedPayload = awsAesCipherEncryptor.decrypt(encryptedPayload);
        assertEquals(PLAIN_PAYLOAD, new String(decryptedPayload, StandardCharsets.UTF_8));
    }

    @Test
    public void autoCloseCache() throws Exception {
        VersionedSecretCache secretCache1 = mock(VersionedSecretCache.class);
        when(secretCache1.getSecretValue(any())).thenReturn(secretValueResult);
        try (AWSAESCipherEncryptor encryptor = new AWSAESCipherEncryptor(secretCache1, SECRET_ARN, SECRET_KEY_NAME, IV_KEY_NAME)) {
            encryptor.encrypt(PLAIN_PAYLOAD);
        }
        verify(secretCache1, atLeastOnce()).close();
    }

    // Additional legacy encrypt resilience

    @Test
    public void legacyEncrypt_sameInstance_samePlaintext_twice_producesSameCipher_andDecrypts() {
        String c1 = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
        String c2 = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);

        // Deterministic under legacy (same secrets -> same IV in GCM)
        assertEquals(c1, c2);

        assertEquals(PLAIN_PAYLOAD, awsAesCipherEncryptor.decrypt(c1));
        assertEquals(PLAIN_PAYLOAD, awsAesCipherEncryptor.decrypt(c2));
    }

    @Test
    public void legacyEncrypt_sameInstance_differentPlaintexts_bothDecrypt() {
        String pA = "alpha-" + PLAIN_PAYLOAD;
        String pB = "beta-" + PLAIN_PAYLOAD;

        String cA = awsAesCipherEncryptor.encrypt(pA);
        String cB = awsAesCipherEncryptor.encrypt(pB);

        assertTrue(StringUtils.isNotBlank(cA));
        assertTrue(StringUtils.isNotBlank(cB));
        assertEquals(pA, awsAesCipherEncryptor.decrypt(cA));
        assertEquals(pB, awsAesCipherEncryptor.decrypt(cB));
    }

    @Test
    public void legacyEncrypt_twoDifferentInstances_sameSecrets_samePlaintext_sameCipher_andDecrypts() {
        // New instance with the same secret cache (same secrets for this test)
        AWSAESCipherEncryptor second =
                new AWSAESCipherEncryptor(secretCache, SECRET_ARN, SECRET_KEY_NAME, IV_KEY_NAME);

        String c1 = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
        String c2 = second.encrypt(PLAIN_PAYLOAD);

        // Still deterministic across instances when secrets are identical
        assertEquals(c1, c2);

        assertEquals(PLAIN_PAYLOAD, awsAesCipherEncryptor.decrypt(c1));
        assertEquals(PLAIN_PAYLOAD, second.decrypt(c2));
    }

    @Test
    public void legacyEncrypt_manyTimes_loop_noException_andAllDecrypt() {
        final int N = 50;
        String[] ct = new String[N];

        for (int i = 0; i < N; i++) {
            ct[i] = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
            assertTrue(StringUtils.isNotBlank(ct[i]));
        }
        for (int i = 0; i < N; i++) {
            assertEquals(PLAIN_PAYLOAD, awsAesCipherEncryptor.decrypt(ct[i]));
        }
    }

    // ------------------------------------------------------------
    // Failure paths (legacy) – ensure we throw
    // ------------------------------------------------------------

    @Test(expected = RuntimeException.class)
    public void decrypt_throwRuntimeException() {
        String encryptedPayload = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
        assertTrue(StringUtils.isNotBlank(encryptedPayload));

        when(secretCache.getSecretValue(any())).thenReturn(invalidSecretValueResult);
        awsAesCipherEncryptor.decrypt(encryptedPayload);
    }

    @Test(expected = RuntimeException.class)
    public void decryptByte_throwRuntimeException() {
        byte[] encryptedPayload = awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8));
        assertTrue(encryptedPayload.length > 0);

        when(secretCache.getSecretValue(any())).thenReturn(invalidSecretValueResult);
        awsAesCipherEncryptor.decrypt(encryptedPayload);
    }

    @Test(expected = RuntimeException.class)
    public void encrypt_throwRuntimeException() {
        when(secretCache.getSecretValue(any())).thenReturn(invalidSecretValueResult);
        awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD);
    }

    @Test(expected = RuntimeException.class)
    public void encryptByte_throwRuntimeException() {
        when(secretCache.getSecretValue(any())).thenReturn(invalidSecretValueResult);
        awsAesCipherEncryptor.encrypt(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8));
    }

    @Test(expected = RuntimeException.class)
    public void encryptWithMetadata_throwRuntimeException() {
        when(secretCache.getSecretValue(any())).thenReturn(invalidSecretValueResult);
        awsAesCipherEncryptor.encryptWithMetadata(PLAIN_PAYLOAD);
    }

    // ------------------------------------------------------------
    // v2 decrypt-only tests (OK: decrypt path auto-detects)
    // ------------------------------------------------------------

    @Test
    public void decrypt_v2String_autoDetect_succeeds() throws Exception {
        byte[] v2Envelope = makeV2Envelope(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8), dynamicSecretsJson);
        String v2Encoded = Base64.getUrlEncoder().withoutPadding().encodeToString(v2Envelope);

        String decrypted = awsAesCipherEncryptor.decrypt(v2Encoded);
        assertEquals(PLAIN_PAYLOAD, decrypted);
    }

    @Test
    public void decrypt_v2Bytes_autoDetect_succeeds() throws Exception {
        byte[] v2Envelope = makeV2Envelope(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8), dynamicSecretsJson);

        byte[] decrypted = awsAesCipherEncryptor.decrypt(v2Envelope);
        assertEquals(PLAIN_PAYLOAD, new String(decrypted, StandardCharsets.UTF_8));
    }

    @Test(expected = RuntimeException.class)
    public void decrypt_v2String_corrupted_throws() throws Exception {
        byte[] v2Envelope = makeV2Envelope(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8), dynamicSecretsJson);
        v2Envelope[v2Envelope.length - 1] ^= 0x01; // corrupt GCM tag
        String bad = Base64.getUrlEncoder().withoutPadding().encodeToString(v2Envelope);

        awsAesCipherEncryptor.decrypt(bad);
    }

    @Test(expected = RuntimeException.class)
    public void decrypt_v2Bytes_corrupted_throws() throws Exception {
        byte[] v2Envelope = makeV2Envelope(PLAIN_PAYLOAD.getBytes(StandardCharsets.UTF_8), dynamicSecretsJson);
        v2Envelope[5] ^= 0x7F; // corrupt early byte

        awsAesCipherEncryptor.decrypt(v2Envelope);
    }

    // -------------------- Helpers --------------------

    /**
     * Builds the v2 envelope exactly as the decryptor expects:
     *   bytes = "iv_" (3) || IV (12) || (AES/GCM/NoPadding ciphertext || 16-byte tag)
     * using the SAME key contract as the implementation (key string's UTF-8 bytes).
     */
    private static byte[] makeV2Envelope(byte[] plaintext, String secretsJsonString) throws Exception {
        String keyStr = com.fasterxml.jackson.databind.json.JsonMapper.builder().build()
                .readTree(secretsJsonString)
                .get(SECRET_KEY_NAME).textValue();

        byte[] keyBytes = keyStr.getBytes(StandardCharsets.UTF_8);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, keySpec, new GCMParameterSpec(128, iv));
        byte[] ctAndTag = c.doFinal(plaintext);

        byte[] out = new byte[3 + iv.length + ctAndTag.length];
        out[0] = 'i'; out[1] = 'v'; out[2] = '_';
        System.arraycopy(iv, 0, out, 3, iv.length);
        System.arraycopy(ctAndTag, 0, out, 3 + iv.length, ctAndTag.length);
        return out;
    }

    private static String asciiRandom(int len) {
        // Restricted to visible ASCII so UTF-8 byte length == char length
        final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
        Random r = new SecureRandom();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }
}
