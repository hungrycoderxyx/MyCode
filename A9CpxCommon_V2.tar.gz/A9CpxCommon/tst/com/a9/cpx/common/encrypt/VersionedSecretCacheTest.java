package com.a9.cpx.common.encrypt;

import com.amazonaws.secretsmanager.caching.SecretCacheConfiguration;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.DescribeSecretResult;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import org.junit.Before;
import org.junit.Test;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class VersionedSecretCacheTest {
    private static final String SECRET_ARN = "arn:secretmanager";
    private static final String SECRET_VERSION1 = "V1";
    private static final String SECRET_VERSION2 = "V2";
    private static final String SECRET_STRING = "it's a secret";
    private Map<String, List<String>> VERSION_IDS_TO_STAGES = new HashMap<>();
    private VersionedSecretCache versionedSecretCache;
    private AWSSecretsManager secretsManager;
    private DescribeSecretResult describeSecretResult;
    private GetSecretValueResult getSecretResult;
    private SecretCacheConfiguration config;

    @Before
    public void setup() {
        VERSION_IDS_TO_STAGES.put(SECRET_VERSION2, Arrays.asList(SecretCacheConfiguration.DEFAULT_VERSION_STAGE));
        VERSION_IDS_TO_STAGES.put(SECRET_VERSION1, Arrays.asList("AWSPREVIOUS"));
        describeSecretResult = new DescribeSecretResult();
        describeSecretResult.setARN(SECRET_ARN);
        describeSecretResult.setVersionIdsToStages(VERSION_IDS_TO_STAGES);
        getSecretResult = new GetSecretValueResult();
        getSecretResult.setVersionId(SECRET_VERSION2);
        getSecretResult.setSecretString(SECRET_STRING);
        getSecretResult.setSecretBinary(ByteBuffer.wrap(SECRET_STRING.getBytes()));
        secretsManager = mock(AWSSecretsManager.class);
        config = mock(SecretCacheConfiguration.class);
        when(config.getMaxCacheSize()).thenReturn(SecretCacheConfiguration.DEFAULT_MAX_CACHE_SIZE);
        when(config.getVersionStage()).thenReturn(SecretCacheConfiguration.DEFAULT_VERSION_STAGE);
        when(config.getClient()).thenReturn(secretsManager);
        when(secretsManager.describeSecret(any())).thenReturn(describeSecretResult);
        when(secretsManager.getSecretValue(any())).thenReturn(getSecretResult);
        versionedSecretCache = new VersionedSecretCache(config);
    }

    @Test
    public void testGetCachedSecretString() {
        assertEquals(SECRET_STRING, versionedSecretCache.getSecretString(SECRET_ARN));
    }

    @Test
    public void testGetCachedSecretBinary() {
        assertEquals(ByteBuffer.wrap(SECRET_STRING.getBytes()), versionedSecretCache.getSecretBinary(SECRET_ARN));
    }

    @Test
    public void testGetCachedSecretStringReturnsNullWhenSecretNull() {
        when(secretsManager.describeSecret(any())).thenReturn(null);
        when(secretsManager.getSecretValue(any())).thenReturn(null);
        assertNull(versionedSecretCache.getSecretString(SECRET_ARN));
    }

    @Test
    public void testGetCachedSecretBinaryReturnsNullWhenSecretNull() {
        when(secretsManager.describeSecret(any())).thenReturn(null);
        when(secretsManager.getSecretValue(any())).thenReturn(null);
        assertNull(versionedSecretCache.getSecretBinary(SECRET_ARN));
    }

    @Test
    public void testGetCachedSecretValue() {
        assertEquals(getSecretResult, versionedSecretCache.getSecretValue(SECRET_ARN));
    }

    @Test
    public void testGetCachedSecretStringAfterRefreshNow() throws InterruptedException {
        assertTrue(versionedSecretCache.refreshNow(SECRET_ARN));
        assertEquals(SECRET_STRING, versionedSecretCache.getSecretString(SECRET_ARN));
    }

    @Test
    public void testSameResultsUsingDifferentConstructors() {
        VersionedSecretCache configCache = new VersionedSecretCache(config);
        VersionedSecretCache clientCache = new VersionedSecretCache(secretsManager);
        String configCacheResult = configCache.getSecretString(SECRET_ARN);
        String clientCacheResult = clientCache.getSecretString(SECRET_ARN);
        assertEquals(SECRET_STRING, configCacheResult);
        assertEquals(configCacheResult, clientCacheResult);
    }
}
