/*
 * Copyright (c) 2010  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.test;

import com.a9.cpx.common.util.StringUtil;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class StringUtilTest {

    @Test
    public void testJoin() throws Exception {

        assertEquals("abc\ndef\nghi", StringUtil.join(Arrays.asList("abc", "def", "ghi"), null));
        assertEquals("abc,def,ghi", StringUtil.join(Arrays.asList("abc", "def", "ghi"), ","));
        assertEquals("abc,,def,,ghi", StringUtil.join(Arrays.asList("abc", "def", "ghi"), ",,"));
        assertEquals("abc", StringUtil.join(Arrays.asList("abc"), ",,"));
        assertEquals("", StringUtil.join(Arrays.asList(""), ",,"));
        try {
            assertEquals("", StringUtil.join(null, ",,"));
            fail("null pointer exception expected");
        } catch (NullPointerException e) {
            // ok
        }
    }

    @Test
    public void testIsNullOrEmpty() throws Exception {

        assertTrue(StringUtil.isNullOrEmpty(null));
        assertTrue(StringUtil.isNullOrEmpty(""));
        assertFalse(StringUtil.isNullOrEmpty("abc"));
        assertFalse(StringUtil.isNullOrEmpty(" "));
        assertFalse(StringUtil.isNullOrEmpty("\n"));
    }

    @Test
    public void testAppendJavascriptCommentToBuffer() throws Exception {

        {
            StringBuilder sb = new StringBuilder();
            sb.append("aa");
            StringUtil.appendJavascriptCommentToBuffer(sb, "AAA");
            sb.append("bb");
            assertEquals("aa// AAA\nbb", sb.toString());
        }
        {
            StringBuilder sb = new StringBuilder();
            sb.append("aa");
            StringUtil.appendJavascriptCommentToBuffer(sb, "");
            sb.append("bb");
            assertEquals("aa// \nbb", sb.toString());
        }
        {
            StringBuilder sb = new StringBuilder();
            sb.append("aa");
            StringUtil.appendJavascriptCommentToBuffer(sb, "AAA//\n/*ABC*/\n//DEF\n");
            sb.append("bb");
            assertEquals("aa// AAA//\n// /*ABC*/\n// //DEF\nbb", sb.toString());
        }
        {
            StringBuilder sb = new StringBuilder();
            sb.append("aa");
            StringUtil.appendJavascriptCommentToBuffer(sb, "AAA//\n/*ABC*/\n//DEF\n\n");
            sb.append("bb");
            assertEquals("aa// AAA//\n// /*ABC*/\n// //DEF\n// \nbb", sb.toString());
        }
        {
            StringBuilder sb = new StringBuilder();
            sb.append("aa");
            StringUtil.appendJavascriptCommentToBuffer(sb, null);
            sb.append("bb");
            assertEquals("aa// \nbb", sb.toString());
        }
    }

    @Test
    public void testVerifyJSIdentifier() throws Exception {

        List<String> good = Arrays.asList("a", "ab", "$", "$a", "_", "_a", "abc$", "a_b", "a123$", "a123");
        List<String> bad = Arrays.asList("continue", "true", "false", "null", "a b", "1", "1a", "1,b", "a()");

        for (String s : good) {
            assertTrue(s, StringUtil.isJavascriptIdentifierValid(s));
        }

        for (String s : bad) {
            assertFalse(s, StringUtil.isJavascriptIdentifierValid(s));
        }
    }
}
