/*
 * Copyright (c) 2010  A9.com, Inc. or its affiliates.
 * All Rights Reserved.
 *
 */

package com.a9.cpx.common.test;

import com.a9.cpx.common.util.GenericFactory;
import com.a9.cpx.common.util.Pair;
import com.a9.cpx.common.util.URLUtil;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class URLUtilTest {

    @Test
    public void testAppendParameters() throws Exception {

        Collection<Pair<String,String>> parameters = null;
        assertEquals("http://foo.bar", callAppendParametersToUrl("http://foo.bar", parameters, true));
        assertEquals("https://foo.bar", callAppendParametersToUrl("https://foo.bar", parameters, true));
        assertEquals("http://foo.bar", callAppendParametersToUrl("http://foo.bar", parameters, false));
        assertEquals("https://foo.bar", callAppendParametersToUrl("https://foo.bar", parameters, false));
        parameters = GenericFactory.newArrayList();
        assertEquals("http://foo.bar", callAppendParametersToUrl("http://foo.bar", parameters, true));
        assertEquals("https://foo.bar", callAppendParametersToUrl("https://foo.bar", parameters, true));
        assertEquals("http://foo.bar", callAppendParametersToUrl("http://foo.bar", parameters, false));
        assertEquals("https://foo.bar", callAppendParametersToUrl("https://foo.bar", parameters, false));
        parameters.add(new Pair<String,String>("abc", "def"));
        assertEquals("http://foo.bar?abc=def", callAppendParametersToUrl("http://foo.bar", parameters, true));
        assertEquals("https://foo.bar?abc=def", callAppendParametersToUrl("https://foo.bar", parameters, true));
        assertEquals("http://foo.bar?abc=def", callAppendParametersToUrl("http://foo.bar", parameters, false));
        assertEquals("https://foo.bar?abc=def", callAppendParametersToUrl("https://foo.bar", parameters, false));
        parameters.add(new Pair<String,String>("ghi", "jkl"));
        assertEquals("http://foo.bar?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar", parameters, true));
        assertEquals("https://foo.bar?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar", parameters, true));
        assertEquals("http://foo.bar?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar", parameters, false));
        assertEquals("https://foo.bar?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar", parameters, false));

        assertEquals("http://foo.bar/?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/", parameters, true));
        assertEquals("https://foo.bar/?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/", parameters, true));
        assertEquals("http://foo.bar/?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/?", parameters, true));
        assertEquals("https://foo.bar/?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/?", parameters, true));

        assertEquals("http://foo.bar?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar?a=b", parameters, true));
        assertEquals("https://foo.bar?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar?a=b", parameters, true));
        assertEquals("http://foo.bar?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar?a=b", parameters, false));
        assertEquals("https://foo.bar?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar?a=b", parameters, false));

        assertEquals("http://foo.bar/duh?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh", parameters, true));
        assertEquals("https://foo.bar/duh?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh", parameters, true));
        assertEquals("http://foo.bar/duh?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh", parameters, false));
        assertEquals("https://foo.bar/duh?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh", parameters, false));

        assertEquals("http://foo.bar/duh/?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh/", parameters, true));
        assertEquals("https://foo.bar/duh/?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh/", parameters, true));
        assertEquals("http://foo.bar/duh/?abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh/?", parameters, true));
        assertEquals("https://foo.bar/duh/?abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh/?", parameters, true));

        assertEquals("http://foo.bar/duh?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh?a=b", parameters, true));
        assertEquals("https://foo.bar/duh?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh?a=b", parameters, true));
        assertEquals("http://foo.bar/duh?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("http://foo.bar/duh?a=b", parameters, false));
        assertEquals("https://foo.bar/duh?a=b&abc=def&ghi=jkl", callAppendParametersToUrl("https://foo.bar/duh?a=b", parameters, false));

        parameters.add(new Pair<String,String>("xxx", "z%=z"));
        assertEquals("http://foo.bar/duh?a=b&abc=def&ghi=jkl&xxx=z%25%3Dz", callAppendParametersToUrl("http://foo.bar/duh?a=b", parameters, true));
        assertEquals("https://foo.bar/duh?a=b&abc=def&ghi=jkl&xxx=z%25%3Dz", callAppendParametersToUrl("https://foo.bar/duh?a=b", parameters, true));


        try {
            URLUtil.encodeAndAppendParametersToUrl("http://foo.bar:abc", parameters, "UTF-8");
            fail("bad url passed");
        } catch (MalformedURLException e) {
            // OK
        }


    }

    private String callAppendParametersToUrl(String s, Collection<Pair<String, String>> parameters, boolean encode) throws MalformedURLException, UnsupportedEncodingException {
        String ret;
        if (encode)
            ret = URLUtil.encodeAndAppendParametersToUrl(s, parameters, "UTF-8");
        else
            ret = URLUtil.appendEncodedParametersToUrl(s, parameters);
        new URL(ret); // make sure URL is valid
        return ret;
    }
}
