package com.a9.cpx.common.test;

import com.a9.cpx.common.util.CFIDUtil;
import org.junit.BeforeClass;
import org.junit.Test;

import amazon.platform.config.AppConfig;

import static org.junit.Assert.assertEquals;
import static com.a9.cpx.common.util.CFIDUtil.REGION_ID_KEY;

public class CFIDUtilTest
{
    @BeforeClass
    public static void initAppConfig()
    {
        System.setProperty("amazon.platform.config.validate", "false");
        if (!AppConfig.isInitialized()) {
            AppConfig.initialize("test", null, APP_CONFIG_ARGS);
        }
        AppConfig.insertInteger(REGION_ID_KEY, DEFAULT_REGION_ID);
    }

    @Test
    public void testAppConfig() throws Exception
    {
        checkCFID(DEFAULT_REGION_ID, CFIDUtil.createCfId());
    }

    @Test
    public void testDifferentRegions() throws Exception
    {
        checkCFID(1, CFIDUtil.createCfId(1));
        checkCFID(9, CFIDUtil.createCfId(9));
        checkCFID(10, CFIDUtil.createCfId(10));
        checkCFID(99, CFIDUtil.createCfId(99));
    }

    private void checkCFID(int regionId, long cfid) throws Exception
    {
        String cfidString = String.valueOf(cfid);
        // Check last two digits are equals to region id
        assertEquals(regionId, cfid % 100);
        // Check length is 13 digits
        assertEquals(13, cfidString.length());
        // Check 10th number is 0
        assertEquals(0, Character.getNumericValue(cfidString.charAt(9)));
    }

    private static final int DEFAULT_REGION_ID = 1;
    private static final String[] APP_CONFIG_ARGS = new String[] { "--root=/tmp", "--domain=test", "--realm=USAmazon" };
}
