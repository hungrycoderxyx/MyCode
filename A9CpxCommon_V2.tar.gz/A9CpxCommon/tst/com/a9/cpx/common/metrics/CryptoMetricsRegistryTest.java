package com.a9.cpx.common.metrics;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.After;
import org.junit.Test;

public class CryptoMetricsRegistryTest {

    @After
    public void reset() {
        // Put the registry back into a known state for other tests
        CryptoMetricsRegistry.set(new NoopCryptoMetrics());
    }

    @Test
    public void default_isNoop() {
        assertTrue(CryptoMetricsRegistry.get() instanceof NoopCryptoMetrics);
    }

    @Test
    public void set_replacesImplementation() {
        CryptoMetrics mock = mock(CryptoMetrics.class);
        CryptoMetricsRegistry.set(mock);
        assertSame(mock, CryptoMetricsRegistry.get());
    }

    @Test
    public void install_doesNotOverwriteWhenAlreadySet() {
        CryptoMetrics first = mock(CryptoMetrics.class, "first");
        CryptoMetrics second = mock(CryptoMetrics.class, "second");

        // Simulate prior initialization
        CryptoMetricsRegistry.set(first);

        // Now install() should not override
        CryptoMetricsRegistry.install(second);
        assertSame(first, CryptoMetricsRegistry.get());
    }
}
