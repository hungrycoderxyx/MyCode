package com.a9.cpx.common.metrics;

import org.junit.Test;

public class NoopCryptoMetricsTest {

    @Test
    public void methods_doNothingAndDoNotThrow() {
        CryptoMetrics m = new NoopCryptoMetrics();
        m.decryptVersion("legacy");
        m.decryptVersion("new");
        m.decryptFailure("failure");
        // no assertions needed – the test passes if nothing throws
    }
}
