## FAQ

### Install Protobuf
Follow the following steps to install protobuf to your local / cloud desktop:
1. Download protobuf 3.11.4 from https://github.com/protocolbuffers/protobuf/releases/download/v3.11.4/protobuf-all-3.11.4.zip
2. Unzip downloaded files, and try the following command to install protobuf
```angular2html
./configure
make
sudo make install
```
3. Verifify installation with `protoc --version`. You should see `libprotoc 3.11.4` as output. 
4. You should now be able to compile proto to java by running `protoc --java_out={{path_to_package_src}} --proto_path={{path_directory_depend_proto_files}} {{path_to_proto_to_compile}}`.

### Not Having Syntax Hint from IDE on 

Need to compile the corresponding `.proto` to Java classes to let IDE pick up the syntax prompting. 

Command: `protoc --java_out={{path_to_package_src}} --proto_path={{path_directory_depend_proto_files}} {{path_to_proto_to_compile}}`

Example: `protoc --java_out=/Volumes/workplace/statelessClick/src/AaxPixelUrlProcessor/src/ --proto_path=/Volumes/workplace/statelessClick/src/AaxPixelUrlProcessor/src/com/a9/clickurl/proto/ /Volumes/workplace/lep_impression/src/AaxPixelUrlProcessor/src/com/a9/clickurl/proto/AdspClickPayload.proto`

See [Protobuf Language guide](https://protobuf.dev/programming-guides/proto3/#generating) for more details.

# AaxPixelUrlProcessor



_TODO: Add a summary of this package_

_TODO: Update the version set in the links below_

## Resources

- [Javadocs](https://code.amazon.com/packages/AaxPixelUrlProcessor/releases/1.0/latest_artifact?version_set=TODO&path=brazil-documentation/javadoc/index.html)
- [Other Reports](https://code.amazon.com/packages/AaxPixelUrlProcessor/releases/1.0/latest_artifact?version_set=TODO&path=brazil-documentation/index.html)

