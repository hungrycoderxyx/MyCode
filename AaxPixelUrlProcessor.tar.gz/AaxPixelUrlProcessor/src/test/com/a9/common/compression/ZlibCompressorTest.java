package com.a9.common.compression;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.junit.Before;
import org.junit.Test;

public class ZlibCompressorTest {

    private ZlibCompressor compressor;

    @Before
    public void setUp() {
        compressor = new ZlibCompressor();
    }

    @Test
    public void testCompressDecompress_BasicString() {
        String original = "{\"sourceId\": 200, \"optOutStatus\": \"UNKNOWN\", \"bidIpAddress\": \"10.85.219.0\", \"cookiesToSet\": [{\"path\": \"/\", \"maxAge\": 613183120, \"domain\": \".amazon-adsystem.com\", \"name\": \"ad-id\", \"secure\": false, \"value\": \"A44QbUzSikycjjaPV3CNnks\", \"version\": 0 } ], \"publisherUid\": \"8a3e2b043f791eebaef51e67683f82a14478eacb\", \"creativeInfo\": {\"a\": \"AAX\", \"adId\": 1234, \"creativeForJsTest\": false, \"creativeType\": \"html\", \"secureCreative\": false, \"creativeId\": 3859 }, \"requestSegments\": [\"MOBILE_BROWSER_FIREFOX\", \"DEVICE_MacPC\"], \"slotName\": \"unknown\", \"bidTime\": 1501197681332, \"webDTB\": false, \"slotBid\": {\"aaxBoost\": 0, \"demandPriority\": 0, \"rawbid\": 1000000, \"bidCreativeSize\": \"300x250\", \"usedVendors\": [145, 226, 9999 ], \"auctionRank\": 1, \"cacheBidId\": \"bcc7d2bb-b68b-4b29-a29a-5e41540c7d6a\", \"creativeInfo\": {\"a\": \"AAX\", \"adId\": 1234, \"creativeForJsTest\": false, \"creativeType\": \"html\", \"secureCreative\": false, \"creativeId\": 3859 }, \"slotBidLog\": {\"aaa\": \"Mq-fg0SU07Jju4T41bvQeQ\", \"dummyNetworkTiming\": {\"initialized\": 1501197681560, \"finished\": 1501197681561, \"started\": 1501197681560, \"successful\": false }, \"dummyNetworkActualDelay\": 1 }, \"adjustedSupplyCost\": 1000000, \"creativeTypes\": [1013, 1007 ], \"cacheId\": {\"externalCacheLookupIdSecure\": false, \"cacheKey\": \"bcc7d2bb-b68b-4b29-a29a-5e41540c7d6a\", \"cacheKeyGenerationType\": \"RANDOM\", \"externalCacheLookupId\": \"bcc7d2bb-b68b-4b29-a29a-5e41540c7d6a\"}, \"valid\": true, \"bidCreativeHTML\": \"\", \"reportingAdProgramId\": 10913, \"bidderId\": 600, \"creativeCategories\": [8023, 8111 ], \"adInfo\": {\"adId\": 1234, \"campaignId\": 67890, \"creativeId\": 3859, \"advertiserId\": 9999 }, \"bidderBoost\": 0, \"reportingAdvertiserId\": 10926, \"mediaType\": \"D\", \"bidId\": \"Mq-fg0SU07Jju4T41bvQeQ\", \"creativeLanguage\": \"en\", \"productCategories\": [2191, 2193, 2414, 2425, 2022, 2147 ], \"advertiserNames\": [\"AMAZON\", \"walgreen.com\"], \"advertiserURLs\": [\"http://www.amazon.com/gp/product/B007OZNZG0\", \"http://www.walgreens.com/store/catalog/For-Men/Deodorant-Bodyspray/ID=prod5731261&navCount=0&navAction=push-product\"], \"singlePricingConfig\": {\"hardFloor\": {\"pricingAttribute\": \"HARD_FLOOR_DEFAULT\", \"value\": 0 }, \"softFloor\": {\"pricingAttribute\": \"SOFT_FLOOR_DEFAULT\", \"value\": 0 }, \"discountFactor\": {\"pricingAttribute\": \"DISCOUNT_FACTOR_DEFAULT\", \"value\": 1 }, \"listAdjustment\": [] }, \"bid\": 1000000, \"impressionRequestURL\": \"http://adamqa.integ.amazon.com/fcgi-ruby/an2_imp.fcgi?punt=0.0&timedout=0.0&maxBid=1000000\", \"reportingCampaignTypeId\": 10555, \"programId\": 6001 }, \"aaxClearingPrice\": 0, \"aaxClearingPriceType\": \"UNKNOWN\", \"networkId\": 600, \"pricingAdjustment\": {\"subsidyPriceProposed\": 0, \"floatPriceUsed\": 0, \"subsidyPriceUsed\": 0, \"boostedBidPrice\": 0, \"hbKittyIncrement\": 0, \"currentFloatPrice\": 0, \"reservePriceUsed\": 0, \"minEcpm\": 0, \"reservePriceProposed\": 0 }, \"flow\": \"direct\", \"floorPrice\": 0, \"siteUid\": \"4e8b1661f253f88d73660192003eafbf95c4be14\", \"slotSize\": \"300x250\", \"AMANPricingV3\": false, \"AAXSecondBid\": 0, \"sourceType\": \"direct\", \"domainName\": \"unknown\", \"v3PricingRuleDirective\": false, \"networkBidLog\": {\"aaa\": \"Mq-fg0SU07Jju4T41bvQeQ\", \"dummyNetworkTiming\": {\"initialized\": 1501197681560, \"finished\": 1501197681561, \"started\": 1501197681560, \"successful\": false }, \"dummyNetworkActualDelay\": 1 }, \"pricingParams\": {}, \"pricingFlow\": \"AMAZON_OWNED_WEB\", \"pricingInfo\": {\"effectiveEndDate\": 0, \"effectiveBeginDate\": 0, \"pricingInfoChain\": [{\"configName\": \"DEFAULT_FOR_SOURCE\", \"effectiveEndDate\": 0, \"pricingDirective\": {\"rules\": [{\"priority\": 10, \"conditions\": {\"bidderId\": [\"900\", \"901\", \"902\", \"903\", \"904\", \"905\", \"906\"] }, \"pricing\": {\"revShare\": {\"percent\": 100 }, \"floorPriceCPM\": 500000, \"model\": \"revShare\", \"techFee\": {\"percent\": 0 } } } ], \"type\": \"mobileApp\", \"version\": 2, \"enabled\": true }, \"effectiveBeginDate\": 0 } ] }, \"aaxBidAmount\": 1000000, \"responseMediaType\": \"D\", \"pricingPlan\": {\"pricingModel\": \"ARBITRAGE\", \"itemizedDemandCost\": {\"itemizedBreakdown\": {}, \"totalCost\": 0 }, \"itemizedSupplyCost\": {\"itemizedBreakdown\": {}, \"totalCost\": 0 } }, \"publisherId\": 0, \"slotSegments\": [\"MOBILE_BROWSER_FIREFOX\", \"VIEWABILITY_NO_DATA\", \"DEVICE_MacPC\"], \"sourceInfo\": {\"amazonOwned\": true, \"deliveryChannel\": \"Web-OO\", \"direct\": true, \"amazonOnsite\": true, \"disableBrandSafety\": true, \"pricingAmazonOwnedWeb\": true }, \"pageType\": \"unknown\", \"requestId\": \"Mq-fg0SU07Jju4T41bvQeQ\", \"slotPosition\": \"unknown\", \"userIds\": {\"deviceOptout\": \"UNKNOWN\", \"targetingMarketplaceId\": 0, \"recognized\": false, \"need3ppdCm\": false, \"bidderDomainsToCookieMatch\": [], \"sisOptout\": \"UNKNOWN\", \"userOptout\": \"UNKNOWN\"}, \"qualityScore\": 1, \"bidCreativeProvided\": false, \"slotId\": 0, \"channelId\": 99, \"logOptOutString\": \"unknown\", \"mobileDTB\": false, \"experimentsList\": {\"NSA_CONTX_4072\": [{\"eventId\": \"dummyId\", \"treatment\": \"T1\", \"dataVersion\": \"1\", \"eventType\": \"default\"} ], \"VIEWABILITY_MDTB_4103\": [{\"eventId\": \"dummyId\", \"treatment\": \"T1\", \"dataVersion\": \"1\", \"eventType\": \"default\"} ] }, \"bidId\": \"Mq-fg0SU07Jju4T41bvQeQ\", \"testAdNetwork\": {\"externalSSP\": false, \"includeEncryptedDeviceId\": false, \"brandSafetyEnabled\": false, \"useFriendlyIframeForImpression\": false, \"deviceIdMatchTrafficEnabled\": false, \"supportsGzip\": false, \"externalEexSeat\": false, \"adjustSSPRawBid\": false, \"skipAaxEts\": true, \"useUserIdForTracking\": false, \"apiVersion\": \"2.0\", \"useBidPriceForClearing\": false, \"atsCompliant\": false, \"doNotSendWinningPrice\": false, \"supportsMultiSlot\": false, \"requireSTS\": true, \"networkId\": 600, \"supportsMultiSize\": false, \"bidRequestURL\": \"http://adamqa.integ.amazon.com/fcgi-ruby/an2.fcgi?punt=0.0&timedout=0.0&maxBid=1000000\"}, \"site\": \"unknown\", \"targetingInfo\": {\"map\": {\"input\": {\"marketplaceId\": [\"1\"], \"site\": [\"unknown\"], \"sourceInfo\": [\"{sourceId=200, amazonOwned=true, deliveryChannel=Web-OO, direct=true, amazonOnsite=true, disableBrandSafety=true, pricingAmazonOwnedWeb=true}\"], \"clientId\": [\"aax\"], \"ipAddress\": [\"10.85.219.0\"], \"userAgent\": [\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:52.0) Gecko/20100101 Firefox/52.0\"] }, \"request\": {\"dayOfWeek\": [\"Thursday\"], \"hourOfDay\": [\"7PM\"], \"shareOfVoice\": [\"5\"], \"userAgent\": [\"13\", \"2\", \"10\", \"4\"] }, \"hostname\": \"targeting-na-beta-2a-a21a3128.us-west-2.amazon.com\", \"requestID\": \"4cd8fa4f-7322-11e7-b187-87e3ee8ce75e\", \"meta\": {\"request\": {}, \"user\": {}, \"events\": {} }, \"experimental\": {}, \"user\": {\"cghSegments\": [\"0\", \"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\", \"8\", \"9\"], \"metaSegments\": [\"1\", \"4\"] }, \"version\": \"2.0\", \"events\": {} } }, \"reportingAdProgramID\": 10913, \"siteId\": 10702, \"bidUserAgent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:52.0) Gecko/20100101 Firefox/52.0\"}";
        byte[] input = original.getBytes(StandardCharsets.UTF_8);

        byte[] compressed = compressor.compress(input);
        byte[] decompressed = compressor.decompress(compressed);

        assertNotNull(compressed);
        assertNotNull(decompressed);
        assertTrue(compressed.length < input.length);

        String result = new String(decompressed, Charset.forName("UTF-8"));
        assertEquals(original, result);
    }

    @Test
    public void testCompressDecompress_EmptyArray() {
        byte[] input = new byte[0];

        byte[] compressed = compressor.compress(input);
        byte[] decompressed = compressor.decompress(compressed);

        assertNotNull(compressed);
        assertNotNull(decompressed);
        assertEquals(input.length, decompressed.length);

        String result = new String(decompressed, Charset.forName("UTF-8"));
        assertEquals("", result);
    }

    @Test(expected = RuntimeException.class)
    public void testDecompress_InvalidData() {
        byte[] invalidData = "This is not valid compressed data".getBytes(StandardCharsets.UTF_8);
        compressor.decompress(invalidData);
    }

    @Test(expected = NullPointerException.class)
    public void testCompress_NullInput() {
        compressor.compress(null);
    }

    @Test(expected = NullPointerException.class)
    public void testDecompress_NullInput() {
        compressor.decompress(null);

    }
}
