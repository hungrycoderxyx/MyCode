package com.a9.creativefetchurl.common;

import com.a9.clickurl.proto.MMPTrackerInfo;
import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.NoOpEncryptor;
import com.a9.creativefetchurl.proto.CreativeFetchBidContext;
import com.a9.common.proto.ControlFlagMessage;
import com.a9.pixelurl.proto.Regs;
import com.google.common.collect.ImmutableSet;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CreativeFetchBidContextFormatterProtoTest {

    private CreativeFetchBidContextFormatterProto creativeFetchBidContextFormatterProto;

    @Before
    public void setUp() throws Exception {
        creativeFetchBidContextFormatterProto = new CreativeFetchBidContextFormatterProto();
        creativeFetchBidContextFormatterProto.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void testFormatFromStringWithUnsupportedVersion() {
        Assert.assertNull(creativeFetchBidContextFormatterProto.formatFromString("cfv0_encodedString"));
    }

    @Test(expected = AaxUrlProtoParsingException.class)
    public void testFormatFromStringException() {
        creativeFetchBidContextFormatterProto.formatFromString("cfv1_encodedString");
    }

    @Test
    public void testFormatToStringAndFormatFromStringSuccess() {
        CreativeFetchBidContext creativeFetchBidContext = prepareTestProto();
        String encodedString = creativeFetchBidContextFormatterProto.formatToString(creativeFetchBidContext);
        Assert.assertNotNull(encodedString);
        Assert.assertTrue(encodedString.startsWith(creativeFetchBidContextFormatterProto.getCurrentVersionPrefix()));

        CreativeFetchBidContext decodedBidContext = creativeFetchBidContextFormatterProto.formatFromString(encodedString);
        Assert.assertEquals(decodedBidContext, creativeFetchBidContext);
    }


    private CreativeFetchBidContext prepareTestProto() {

        CreativeFetchBidContext.MobileApp mobileApp = CreativeFetchBidContext.MobileApp.newBuilder()
                .setAppId("appId")
                .build();

        CreativeFetchBidContext.UserAgentInfo userAgentInfo = CreativeFetchBidContext.UserAgentInfo.newBuilder()
                .setDeviceType("phone")
                .setOs("IOS")
                .build();

        CreativeFetchBidContext.SlotBid.AdInfo adInfo = CreativeFetchBidContext.SlotBid.AdInfo.newBuilder()
                .setAdId(123L)
                .setCreativeId(456L)
                .setAdvertiserId(789L)
                .setCampaignId(10L)
                .setSpId("DSP:AmazonMobileAppFlowScript")
                .build();

        CreativeFetchBidContext.SlotBid.VideoCreativeInfo videoCreativeInfo = CreativeFetchBidContext.SlotBid.VideoCreativeInfo.newBuilder()
                .setProtocol("VAST 3.0")
                .setApi(-1)
                .build();

        MMPTrackerInfo mmpTrackerInfo = MMPTrackerInfo.newBuilder()
                .setAdTracking(1)
                .setCost(2.0)
                .setCostModel("cpc")
                .setIdfa("idfa")
                .setSha1Udid("sha1Udid")
                .setSiteName("siteDisplayNm23")
                .build();

        ControlFlagMessage controlFlagMessage = ControlFlagMessage.newBuilder()
                .addAllBitmaskChunks(ImmutableSet.of(1))
                .build();

        CreativeFetchBidContext.SlotBid slotBid = CreativeFetchBidContext.SlotBid.newBuilder()
                .setBidId("test_bid_id")
                .setSeatbidBidId("unique_bidder_bid_id")
                .setBidderId(400L)
                .setMtype(1)
                .setBid(10000L)
                .setAdInfo(adInfo)
                .setVideoCreativeInfo(videoCreativeInfo)
                .setMmpTrackerInfo(mmpTrackerInfo)
                .setControlFlags(controlFlagMessage)
                .build();

        CreativeFetchBidContext.BidTimeHostContext bidTimeHostContext = CreativeFetchBidContext.BidTimeHostContext.newBuilder()
                .setHostName("host")
                .setCellId("cellId")
                .setApolloEnv("EU")
                .build();

        return CreativeFetchBidContext.newBuilder()
                .setRequestId("test_req_id")
                .setSourceId(100L)
                .setBidTime(12345L)
                .setSecure(true)
                .setSiteName("amazon.com")
                .setPageType("pageType")
                .setChannelId(99L)
                .setMobileApp(mobileApp)
                .setRegs(Regs.newBuilder().build())
                .setUserAgentInfo(userAgentInfo)
                .setSlotBid(slotBid)
                .setSlotSize("200x400")
                .setBidCacheIdentifier("videoBid")
                .setBidTimeHostContext(bidTimeHostContext)
                .build();
    }
}