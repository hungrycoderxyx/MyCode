package com.a9.pixelurl.common;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.a9.common.NoOpEncryptor;
import com.a9.pixelurl.proto.NiiPixelPayload;
import com.a9.pixelurl.proto.SecureId;

public class NiiPixelPayloadFormatterProtoTest {

    private NiiPixelPayloadFormatterProto pixelPayloadFormatterProto;

    @Before
    public void setup() {
        pixelPayloadFormatterProto = new NiiPixelPayloadFormatterProto();
        pixelPayloadFormatterProto.setEncryptor(new NoOpEncryptor());
    }

    @Test
    public void encryptAndDecryptStringFromFullPayload() {
        String serializedProtoString = pixelPayloadFormatterProto.formatToString(getFullPayload());
        Assert.assertNotNull(serializedProtoString);
        Assert.assertEquals(pixelPayloadFormatterProto.getCurrentVersionPrefix(), serializedProtoString.substring(0, pixelPayloadFormatterProto.getCurrentVersionPrefix().length()));

        NiiPixelPayload payloadDeserialized = pixelPayloadFormatterProto.formatFromString(serializedProtoString);
        Assert.assertEquals("abc", payloadDeserialized.getSecureId().getRequestId());
        Assert.assertEquals("abc", payloadDeserialized.getSiteName());
    }

    private NiiPixelPayload getFullPayload() {
        SecureId secureId = SecureId.newBuilder()
                                    .setRequestId("abc")
                                    .setSourceId("1200").build();

        NiiPixelPayload.Pricing pricing = NiiPixelPayload.Pricing.newBuilder()
                                                                 .setTotalSupplyCost(123L).build();
        
        NiiPixelPayload.UserIds userIds = NiiPixelPayload.UserIds.newBuilder()
                                                                 .setDeviceId("abc").build();
        
        NiiPixelPayload.SlotBid slotBid = NiiPixelPayload.SlotBid.newBuilder()
                                                                 .setBidId("abc")
                                                                 .setNetworkId(400L)
                                                                 .setProgramId(123L)
                                                                 .setAaxBidAmount(123L)
                                                                 .setSlotSize("abc").build();

        return NiiPixelPayload.newBuilder()
                              .setSecureId(secureId)
                              .setPricing(pricing)
                              .setUserIds(userIds)
                              .setSlotBid(slotBid)
                              .setSiteName("abc")
                              .setPageType("abc")
                              .setSlotName("abc")
                              .setSlotPosition("abc")
                              .setRBidId("abc").build();
    }

    @Test
    public void encryptAndDecryptStringForIncompletePayload() {
        NiiPixelPayload payload = NiiPixelPayload.newBuilder().setSecureId(SecureId.newBuilder().setRequestId("abc").build()).build();
        String serializedProtoString = pixelPayloadFormatterProto.formatToString(payload);
        Assert.assertNotNull(serializedProtoString);
        Assert.assertEquals(pixelPayloadFormatterProto.getCurrentVersionPrefix(), serializedProtoString.substring(0, pixelPayloadFormatterProto.getCurrentVersionPrefix().length()));

        NiiPixelPayload payloadDeserialized = pixelPayloadFormatterProto.formatFromString(serializedProtoString);
        Assert.assertEquals("abc", payloadDeserialized.getSecureId().getRequestId());
    }
}
