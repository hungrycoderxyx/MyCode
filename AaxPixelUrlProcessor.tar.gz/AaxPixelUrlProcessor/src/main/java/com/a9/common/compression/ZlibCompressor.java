package com.a9.common.compression;

import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.cpx.common.util.IOUtil;
import com.a9.log.CommonLogger;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import javax.annotation.Nonnull;

public class ZlibCompressor implements PayloadCompressor {

    private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());

    @Override
    public byte[] compress(@Nonnull byte[] v) {
        Deflater deflater = new Deflater(Deflater.BEST_SPEED);
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            try (DeflaterOutputStream dfos = new DeflaterOutputStream(baos, deflater)) {
                dfos.write(v);
            }
            byte[] ret = baos.toByteArray();
            logger.debug("Deflated byte array length={}, original input length={}", ret.length, v.length);
            return ret;
        } catch (IOException e) {
            logger.debug(e);
            throw new RuntimeException(e);
        } finally {
            deflater.end();
        }
    }

    @Override
    public byte[] decompress(@Nonnull byte[] v) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(v)) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try {
                InputStream decompressor = new InflaterInputStream(bais);
                IOUtil.copyStream(decompressor, baos, 1024, true);
            } finally {
                baos.close();
            }
            return baos.toByteArray();
        } catch (IOException e) {
            logger.debug(e);
            throw new RuntimeException(e);
        }
    }
}
