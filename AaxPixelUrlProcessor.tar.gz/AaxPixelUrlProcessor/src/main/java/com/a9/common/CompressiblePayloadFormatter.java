package com.a9.common;

public interface CompressiblePayloadFormatter<T> extends PayloadFormatter<T> {
    String formatToString(T request, boolean compress);
    String getCurrentCompressedVersionPrefix();
}
