package com.a9.common;

import static com.a9.cpx.common.util.URLEncoderUTF8.urlEncode;
import java.util.Base64;


public interface PayloadFormatter<T> {
    String formatToString(T request);

    T formatFromString(String payload);
    
    String getCurrentVersionPrefix();
}
