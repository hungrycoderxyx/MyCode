package com.a9.common;

public class AaxUrlProtoParsingException extends RuntimeException {

    public AaxUrlProtoParsingException(String message) {
        super(message);
    }

    public AaxUrlProtoParsingException(String message, Throwable e) {
        super(message, e);
    }
}
