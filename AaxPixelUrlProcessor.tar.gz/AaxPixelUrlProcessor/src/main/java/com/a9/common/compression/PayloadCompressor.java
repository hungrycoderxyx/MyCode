package com.a9.common.compression;

import javax.annotation.Nonnull;

public interface PayloadCompressor {
    byte[] compress(@Nonnull byte[] bytes);
    byte[] decompress(@Nonnull byte[] bytes);
}
