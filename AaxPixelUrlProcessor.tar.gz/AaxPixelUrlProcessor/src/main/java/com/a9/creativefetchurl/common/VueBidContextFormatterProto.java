package com.a9.creativefetchurl.common;

import com.a9.common.AaxUrlProtoParsingException;
import com.a9.common.PayloadFormatter;
import com.a9.common.UrlProtoEncodingUtils;
import com.a9.cpx.common.encrypt.Encryptor;
import com.a9.cpx.common.util.CallSiteHelper;
import com.a9.creativefetchurl.proto.VueBidContext;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.a9.log.CommonLogger;
import com.google.common.collect.ImmutableSet;

import java.util.Base64;
import java.util.Collections;
import java.util.Set;

import static com.a9.common.UrlProtoEncodingUtils.serializeForUrl;
import static com.a9.cpx.common.util.URLEncoderUTF8.urlDecode;

@NoArgsConstructor
@Setter
public class VueBidContextFormatterProto implements PayloadFormatter<VueBidContext>  {
        private static final CommonLogger logger = CommonLogger.getLogger(CallSiteHelper.getCallingClassName());
        public static final String PROTO_VERSION_V1 = UrlProtoEncodingUtils.buildVersionPrefix(Collections.singletonList("vuev1"));
        private final Set<String> SUPPORTED_VERSIONS = ImmutableSet.of(PROTO_VERSION_V1);
        private Encryptor encryptor;

        @Override
        public String formatToString(VueBidContext request) {
            byte[] encryptedBytes = encryptor.encrypt(request.toByteArray());
            return serializeForUrl(encryptedBytes, getCurrentVersionPrefix());
        }

        @Override
        public VueBidContext formatFromString(String vueString) {

            String decodedUrl = urlDecode(vueString);
            String extractedVersionPrefix = UrlProtoEncodingUtils.extractVersionPrefix(decodedUrl);
            if (!UrlProtoEncodingUtils.isCompatiblePayload(SUPPORTED_VERSIONS, extractedVersionPrefix)) {
                return null;
            }

            String payloadProStringBase64URLSafe = decodedUrl.substring(extractedVersionPrefix.length());
            try {
                if (extractedVersionPrefix.equals(PROTO_VERSION_V1)) {
                    return VueBidContext.parseFrom(encryptor.decrypt(Base64.getUrlDecoder().decode(payloadProStringBase64URLSafe)));
                }
                return null;
            } catch(Exception e) {
                throw new AaxUrlProtoParsingException("failed to format creative bidContext from string", e);
            }
        }

        @Override
        public String getCurrentVersionPrefix() {
            return PROTO_VERSION_V1;
        }


    }
