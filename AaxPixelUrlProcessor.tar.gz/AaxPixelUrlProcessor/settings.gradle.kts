plugins {
    id("brazil-setup")
}

rootProject.name = "AaxPixelUrlProcessor"
